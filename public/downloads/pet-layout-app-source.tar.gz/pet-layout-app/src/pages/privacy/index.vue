<template>
  <view class="page">
    <view class="content">
      <text class="title">隐私政策</text>
      <text class="update-date">更新日期：2026年4月20日</text>

      <text class="section-title">一、信息收集</text>
      <text class="paragraph">「轻治愈动物笔记」是一款纯本地运行的微信小程序，我们不会收集、存储或上传您的任何个人信息。所有笔记数据、设置偏好均保存在您的设备本地缓存中。</text>

      <text class="section-title">二、数据存储</text>
      <text class="paragraph">1. 所有笔记内容、图片、字体设置、动物解锁状态均存储在微信小程序本地缓存中。\n2. 我们的服务器不保存任何用户数据。\n3. 清除小程序缓存或卸载微信将导致本地数据丢失。</text>

      <text class="section-title">三、广告说明</text>
      <text class="paragraph">本小程序内嵌微信官方广告组件（流量主），可能展示激励视频广告。广告内容由微信平台提供，我们不会收集您的个人兴趣或行为数据进行精准推送。</text>

      <text class="section-title">四、权限使用</text>
      <text class="paragraph">本小程序仅可能使用以下权限：\n1. 相册写入权限：用于保存笔记图片到您的相册。\n2. 不需要微信登录授权、不需要获取您的微信账号信息。</text>

      <text class="section-title">五、未成年人保护</text>
      <text class="paragraph">我们重视未成年人的隐私保护。未成年人应在监护人指导下使用本小程序。</text>

      <text class="section-title">六、联系我们</text>
      <text class="paragraph">如您对本隐私政策有任何疑问，请通过微信小程序平台联系开发者。</text>
    </view>
  </view>
</template>

<style scoped>
.page { min-height: 100vh; background: #FFF9F5; }
.content { padding: 30rpx; }
.title { font-size: 36rpx; font-weight: bold; color: #333; display: block; margin-bottom: 12rpx; }
.update-date { font-size: 24rpx; color: #999; display: block; margin-bottom: 30rpx; }
.section-title { font-size: 30rpx; font-weight: 600; color: #333; display: block; margin: 30rpx 0 16rpx; }
.paragraph { font-size: 28rpx; color: #555; line-height: 1.8; display: block; margin-bottom: 12rpx; }
</style>
