/**
 * CPTI 关系测试核心计分逻辑
 */

// 维度说明
const DIMENSION_MAP = {
  C: '掌控型',
  G: '感温型',
  L: '理智型',
  S: '社交型',
  T: '自由型',
}

/**
 * 计算单题分数
 * @param {Object} question - 题目 { id, title, type, target }
 * @param {string} answer - 'agree' | 'sometimes' | 'disagree'
 * @param {Object} score - 累计分数对象
 */
function calcScore(question, answer, score) {
  const t = question.target
  if (question.type === 'normal') {
    if (answer === 'agree') score[t] += 3
    else if (answer === 'sometimes') score[t] += 1
    else if (answer === 'disagree') score[t] -= 2
  } else {
    // 反向题
    if (answer === 'agree') score[t] -= 2
    else if (answer === 'sometimes') score[t] -= 1
    else if (answer === 'disagree') score[t] += 3
  }
}

/**
 * 归一化到 0-100
 */
function normalize(score) {
  const arr = [score.C, score.G, score.L, score.S, score.T]
  const min = Math.min(...arr)
  const max = Math.max(...arr)
  const res = {}
  for (let k in score) {
    if (max === min) {
      res[k] = 50
    } else {
      res[k] = Math.round(((score[k] - min) / (max - min)) * 100)
    }
  }
  return res
}

/**
 * 获取主维度（得分最高的维度字母）
 */
function getMainType(normalized) {
  let maxVal = -1, mainKey = 'C'
  for (let k of ['C', 'G', 'L', 'S', 'T']) {
    if (normalized[k] > maxVal) {
      maxVal = normalized[k]
      mainKey = k
    }
  }
  return mainKey
}

/**
 * 匹配相似度（0-100）
 */
function calcSimilarity(a, b) {
  let total = 0
  for (let k of ['C', 'G', 'L', 'S', 'T']) {
    total += Math.abs(a[k] - b[k])
  }
  return Math.max(0, Math.round(100 - total / 5))
}

/**
 * 根据分数差值匹配关系
 */
function matchRelation(diff, relations) {
  for (let r of relations) {
    if (diff >= r.min && diff <= r.max) return r
  }
  return relations[relations.length - 1]
}

/**
 * 生成 7 位 CPID
 */
function genId() {
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ123456789'
  let r = ''
  for (let i = 0; i < 7; i++) {
    r += c[Math.floor(Math.random() * c.length)]
  }
  return r
}

module.exports = {
  DIMENSION_MAP,
  calcScore,
  normalize,
  getMainType,
  calcSimilarity,
  matchRelation,
  genId,
}
