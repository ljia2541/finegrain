const allRelations = require('../../data/relations')

Page({
  data: {
    relations: [],
    collected: 0,
    progress: 0,
    showDetail: false,
    showHelpModal: false,
    currentRelation: {},
  },

  onShow() {
    this.loadCollection()
  },

  loadCollection() {
    const unlocked = wx.getStorageSync('unlockedRelationIds') || []
    const relations = allRelations.map(r => ({
      ...r,
      unlocked: unlocked.includes(r.id),
    }))
    const collected = unlocked.length
    this.setData({
      relations,
      collected,
      progress: Math.round(collected / 25 * 100),
    })
  },

  openDetail(e) {
    const idx = e.currentTarget.dataset.index
    const item = this.data.relations[idx]
    if (!item || !item.unlocked) return
    this.setData({ showDetail: true, currentRelation: item })
  },

  closeDetail() {
    this.setData({ showDetail: false })
  },

  noop() {},

  showHelp() {
    this.setData({ showHelpModal: true })
  },

  closeHelp() {
    this.setData({ showHelpModal: false })
  },
})

// 全局工具：匹配成功后记录收集
function collectRelation(relationId) {
  const unlocked = wx.getStorageSync('unlockedRelationIds') || []
  if (!unlocked.includes(relationId)) {
    unlocked.push(relationId)
    wx.setStorageSync('unlockedRelationIds', unlocked)
  }
}

module.exports.collectRelation = collectRelation
