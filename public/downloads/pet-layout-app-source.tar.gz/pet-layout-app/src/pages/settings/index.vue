<template>
  <view class="page">
    <view class="settings-group">
      <text class="group-title">字体</text>
      <view class="setting-item" @tap="goPage('/pages/editor/index')">
        <text class="setting-label">字体与字号</text>
        <text class="setting-arrow">›</text>
      </view>
    </view>

    <view class="settings-group">
      <text class="group-title">数据</text>
      <view class="setting-item" @tap="clearCache">
        <text class="setting-label">清理缓存</text>
        <text class="setting-value">{{ cacheSize }}</text>
      </view>
      <view class="setting-item danger" @tap="resetData">
        <text class="setting-label">重置所有数据</text>
      </view>
    </view>

    <view class="settings-group">
      <text class="group-title">关于</text>
      <view class="setting-item" @tap="goPage('/pages/privacy/index')">
        <text class="setting-label">隐私政策</text>
        <text class="setting-arrow">›</text>
      </view>
      <view class="setting-item" @tap="goPage('/pages/terms/index')">
        <text class="setting-label">用户协议</text>
        <text class="setting-arrow">›</text>
      </view>
      <view class="setting-item">
        <text class="setting-label">版本</text>
        <text class="setting-value">v1.0.0</text>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const cacheSize = ref('计算中…')

// 简单估算缓存大小
try {
  const res = uni.getStorageInfoSync()
  cacheSize.value = ((res.currentSize || 0) / 1024).toFixed(1) + ' KB'
} catch {
  cacheSize.value = '未知'
}

function clearCache() {
  uni.showModal({
    title: '清理缓存',
    content: '将清除临时文件，笔记数据不会丢失',
    success: (res) => {
      if (res.confirm) {
        try { uni.clearStorageSync() } catch {}
        cacheSize.value = '0 KB'
        uni.showToast({ title: '缓存已清理', icon: 'success' })
      }
    },
  })
}

function resetData() {
  uni.showModal({
    title: '⚠️ 重置数据',
    content: '所有笔记、解锁状态、设置将被清除，且无法恢复',
    success: (res) => {
      if (res.confirm) {
        try { uni.clearStorageSync() } catch {}
        uni.showToast({ title: '数据已重置', icon: 'success' })
        setTimeout(() => uni.reLaunch({ url: '/pages/index/index' }), 1000)
      }
    },
  })
}

function goPage(url: string) {
  uni.navigateTo({ url })
}
</script>

<style scoped>
.page { min-height: 100vh; background: #FFF9F5; padding: 20rpx 30rpx; }
.settings-group {
  background: #fff; border-radius: 16rpx; margin-bottom: 24rpx;
  padding: 10rpx 0; overflow: hidden;
}
.group-title {
  font-size: 26rpx; color: #999; padding: 20rpx 30rpx 10rpx; display: block;
}
.setting-item {
  display: flex; align-items: center; justify-content: space-between;
  padding: 28rpx 30rpx; border-bottom: 1rpx solid #f5f5f5;
}
.setting-item:last-child { border-bottom: none; }
.setting-label { font-size: 30rpx; color: #333; }
.setting-value { font-size: 28rpx; color: #999; }
.setting-arrow { font-size: 32rpx; color: #ccc; }
.setting-item.danger .setting-label { color: #E53E3E; }
</style>
