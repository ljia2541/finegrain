const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event, context) => {
  const questions = require('./questions.json')
  const relations = require('./relations.json')

  // 批量写入题目（如果集合为空）
  const qCount = (await db.collection('questions').count()).total
  if (qCount === 0) {
    const tasks = questions.map(q => db.collection('questions').add({ data: q }))
    await Promise.all(tasks)
  }

  // 批量写入关系（如果集合为空）
  const rCount = (await db.collection('relations').count()).total
  if (rCount === 0) {
    const tasks = relations.map(r => db.collection('relations').add({ data: r }))
    await Promise.all(tasks)
  }

  return { success: true, questions: qCount, relations: rCount }
}
