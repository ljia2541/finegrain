module.exports = [
  {
    "id": 1,
    "name": "灵魂挚友",
    "desc": "你们无需多言，就能互相懂得，是灵魂深处契合的知己。",
    "min": 90,
    "max": 100,
    "image": "/images/relations/relation_01.png",
    "gradient": "linear-gradient(135deg, #667eea, #764ba2)"
  },
  {
    "id": 2,
    "name": "另一个我",
    "desc": "性格、喜好、节奏都像照镜子般重合，默契到仿佛同一个人。",
    "min": 85,
    "max": 89,
    "image": "/images/relations/relation_02.png",
    "gradient": "linear-gradient(135deg, #89f7fe, #66a6ff)"
  },
  {
    "id": 3,
    "name": "最佳拍档",
    "desc": "做事效率最高、配合最无缝的组合，无论什么事都能稳稳拿捏。",
    "min": 80,
    "max": 84,
    "image": "/images/relations/relation_03.png",
    "gradient": "linear-gradient(135deg, #f093fb, #f5576c)"
  },
  {
    "id": 4,
    "name": "欢喜冤家",
    "desc": "嘴上互怼不断，心里却格外在意；越相处越亲密，越吵越合拍。",
    "min": 75,
    "max": 79,
    "image": "/images/relations/relation_04.png",
    "gradient": "linear-gradient(135deg, #ff6a00, #ee0979)"
  },
  {
    "id": 5,
    "name": "引路之人",
    "desc": "总能带你看清方向，在你迷路时给你指引，是人生路上的重要光。",
    "min": 70,
    "max": 74,
    "image": "/images/relations/relation_05.png",
    "gradient": "linear-gradient(135deg, #11998e, #38ef7d)"
  },
  {
    "id": 6,
    "name": "专属守护",
    "desc": "下意识护着你、包容你，给足安全感，有TA在你永远能放松。",
    "min": 65,
    "max": 69,
    "image": "/images/relations/relation_06.png",
    "gradient": "linear-gradient(135deg, #fc5c7d, #6a82fb)"
  },
  {
    "id": 7,
    "name": "情绪归宿",
    "desc": "所有委屈、心事、情绪都能放心放下，这里永远有人懂你。",
    "min": 60,
    "max": 64,
    "image": "/images/relations/relation_07.png",
    "gradient": "linear-gradient(135deg, #f6d365, #fda085)"
  },
  {
    "id": 8,
    "name": "坚实底气",
    "desc": "不常联系却永远在你身后，是你遇事时最稳的靠山和力量。",
    "min": 55,
    "max": 59,
    "image": "/images/relations/relation_08.png",
    "gradient": "linear-gradient(135deg, #4facfe, #00f2fe)"
  },
  {
    "id": 9,
    "name": "快乐源泉",
    "desc": "和TA在一起就是笑声不断，元气值拉满，生活被照亮。",
    "min": 50,
    "max": 54,
    "image": "/images/relations/relation_09.png",
    "gradient": "linear-gradient(135deg, #43e97b, #38f9d7)"
  },
  {
    "id": 10,
    "name": "同频知己",
    "desc": "三观契合、频率一致，聊得来、处得舒服，默契又轻松。",
    "min": 45,
    "max": 49,
    "image": "/images/relations/relation_10.png",
    "gradient": "linear-gradient(135deg, #fa709a, #fee140)"
  },
  {
    "id": 11,
    "name": "并肩战友",
    "desc": "一起经历过风雨、拼过目标，是能并肩作战的信任伙伴。",
    "min": 40,
    "max": 44,
    "image": "/images/relations/relation_11.png",
    "gradient": "linear-gradient(135deg, #a18cd1, #fbc2eb)"
  },
  {
    "id": 12,
    "name": "氛围双子",
    "desc": "两人在一起就是热闹制造机，走到哪就把快乐带到哪。",
    "min": 35,
    "max": 39,
    "image": "/images/relations/relation_12.png",
    "gradient": "linear-gradient(135deg, #fddb92, #d1fdff)"
  },
  {
    "id": 13,
    "name": "小众同频",
    "desc": "拥有别人很难懂的共同爱好，只有彼此能get到对方的点。",
    "min": 30,
    "max": 34,
    "image": "/images/relations/relation_13.png",
    "gradient": "linear-gradient(135deg, #c471f5, #fa71cd)"
  },
  {
    "id": 14,
    "name": "完美互补",
    "desc": "一动一静、一冷一热，刚好填补彼此空缺，组合才更完整。",
    "min": 25,
    "max": 29,
    "image": "/images/relations/relation_14.png",
    "gradient": "linear-gradient(135deg, #48c6ef, #6f86d6)"
  },
  {
    "id": 15,
    "name": "温柔包容",
    "desc": "彼此温和耐心，少争执多包容，相处像温水一样舒服。",
    "min": 20,
    "max": 24,
    "image": "/images/relations/relation_15.png",
    "gradient": "linear-gradient(135deg, #e0c3fc, #8ec5fc)"
  },
  {
    "id": 16,
    "name": "自在相处",
    "desc": "不用伪装、不用客气，怎么舒服怎么来，相处轻松无压。",
    "min": 15,
    "max": 19,
    "image": "/images/relations/relation_16.png",
    "gradient": "linear-gradient(135deg, #f6d365, #f5af19)"
  },
  {
    "id": 17,
    "name": "长久陪伴",
    "desc": "感情不喧嚣，却能长久走下去，是细水长流的稳定陪伴。",
    "min": 10,
    "max": 14,
    "image": "/images/relations/relation_17.png",
    "gradient": "linear-gradient(135deg, #667eea, #764ba2)"
  },
  {
    "id": 18,
    "name": "心意相通",
    "desc": "能懂彼此的言外之意，也懂彼此的沉默，默契无形。",
    "min": 5,
    "max": 9,
    "image": "/images/relations/relation_18.png",
    "gradient": "linear-gradient(135deg, #84fab0, #8fd3f4)"
  },
  {
    "id": 19,
    "name": "双向治愈",
    "desc": "互相温暖、互相疗愈，和对方在一起总是安心又平静。",
    "min": 0,
    "max": 4,
    "image": "/images/relations/relation_19.png",
    "gradient": "linear-gradient(135deg, #fccb90, #d57eeb)"
  },
  {
    "id": 20,
    "name": "步调一致",
    "desc": "生活节奏、做事习惯都很契合，不用等待也不用追赶。",
    "min": -5,
    "max": -1,
    "image": "/images/relations/relation_20.png",
    "gradient": "linear-gradient(135deg, #a1c4fd, #c2e9fb)"
  },
  {
    "id": 21,
    "name": "命中遇见",
    "desc": "相遇是一种奇妙缘分，能认识、能相处，本身就是一种幸运。",
    "min": -10,
    "max": -6,
    "image": "/images/relations/relation_21.png",
    "gradient": "linear-gradient(135deg, #d4fc79, #96e6a1)"
  },
  {
    "id": 22,
    "name": "未来同行",
    "desc": "目标相似、方向一致，适合一起走更远、更长久的旅程。",
    "min": -15,
    "max": -11,
    "image": "/images/relations/relation_22.png",
    "gradient": "linear-gradient(135deg, #fbc2eb, #a6c1ee)"
  },
  {
    "id": 23,
    "name": "最懂我的人",
    "desc": "看穿你的逞强，读懂你的脆弱，是真正走进你心里的人。",
    "min": -20,
    "max": -16,
    "image": "/images/relations/relation_23.png",
    "gradient": "linear-gradient(135deg, #ffecd2, #fcb69f)"
  },
  {
    "id": 24,
    "name": "彼此撑腰",
    "desc": "独立却互相支撑，遇事时彼此站边，永远是对方的底气。",
    "min": -25,
    "max": -21,
    "image": "/images/relations/relation_24.png",
    "gradient": "linear-gradient(135deg, #e0c3fc, #8ec5fc)"
  },
  {
    "id": 25,
    "name": "天生一对",
    "desc": "莫名契合、莫名般配，没有理由却相处得极好，是刚刚好。",
    "min": -1000,
    "max": -26,
    "image": "/images/relations/relation_25.png",
    "gradient": "linear-gradient(135deg, #f5af19, #f12711)"
  }
]