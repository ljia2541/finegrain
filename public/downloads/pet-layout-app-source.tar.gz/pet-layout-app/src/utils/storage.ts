/**
 * 轻治愈动物笔记 - 本地存储工具
 * 纯单机模式，所有数据本地缓存
 */

const STORAGE_KEYS = {
  NOTES: 'qzy_notes',
  UNLOCKED: 'qzy_unlocked',
  SETTINGS: 'qzy_settings',
  FONT: 'qzy_font',
  CHECKIN: 'qzy_checkin',
}

// === 笔记管理 ===

export interface NoteRecord {
  id: string
  animalId: string
  content: string
  templateId: string
  fontId: string
  fontSizeId: string
  imagePaths?: string[]
  starred: boolean
  hidden: boolean
  createdAt: number
  updatedAt: number
}

export function getNotes(): NoteRecord[] {
  try {
    const data = uni.getStorageSync(STORAGE_KEYS.NOTES)
    return data ? JSON.parse(data) : []
  } catch {
    return []
  }
}

export function getNotesByAnimal(animalId: string): NoteRecord[] {
  return getNotes().filter((n) => n.animalId === animalId && !n.hidden)
}

export function saveNote(note: NoteRecord): void {
  const notes = getNotes()
  const idx = notes.findIndex((n) => n.id === note.id)
  if (idx >= 0) {
    note.updatedAt = Date.now()
    notes[idx] = note
  } else {
    notes.unshift(note)
  }
  uni.setStorageSync(STORAGE_KEYS.NOTES, JSON.stringify(notes))
  // 自动打卡
  checkinToday()
}

export function deleteNote(id: string): void {
  const notes = getNotes().filter((n) => n.id !== id)
  uni.setStorageSync(STORAGE_KEYS.NOTES, JSON.stringify(notes))
}

export function toggleStar(id: string): void {
  const notes = getNotes()
  const note = notes.find((n) => n.id === id)
  if (note) {
    note.starred = !note.starred
    uni.setStorageSync(STORAGE_KEYS.NOTES, JSON.stringify(notes))
  }
}

export function toggleHidden(id: string): void {
  const notes = getNotes()
  const note = notes.find((n) => n.id === id)
  if (note) {
    note.hidden = !note.hidden
    uni.setStorageSync(STORAGE_KEYS.NOTES, JSON.stringify(notes))
  }
}

// === 动物解锁 ===

export function getUnlockedAnimals(): string[] {
  try {
    const data = uni.getStorageSync(STORAGE_KEYS.UNLOCKED)
    return data ? JSON.parse(data) : ['anan', 'tietie', 'banban']
  } catch {
    return ['anan', 'tietie', 'banban']
  }
}

export function unlockAnimal(animalId: string): void {
  const unlocked = getUnlockedAnimals()
  if (!unlocked.includes(animalId)) {
    unlocked.push(animalId)
    uni.setStorageSync(STORAGE_KEYS.UNLOCKED, JSON.stringify(unlocked))
  }
}

export function isAnimalUnlocked(animalId: string): boolean {
  return getUnlockedAnimals().includes(animalId)
}

// === 字体设置 ===

export interface FontSettings {
  fontId: string
  fontSizeId: string
}

export function getFontSettings(): FontSettings {
  try {
    const data = uni.getStorageSync(STORAGE_KEYS.FONT)
    return data ? JSON.parse(data) : { fontId: 'serif_jp', fontSizeId: 'medium' }
  } catch {
    return { fontId: 'serif_jp', fontSizeId: 'medium' }
  }
}

export function saveFontSettings(settings: FontSettings): void {
  uni.setStorageSync(STORAGE_KEYS.FONT, JSON.stringify(settings))
}

// === 全局设置 ===

export interface AppSettings {
  firstUseDate?: number
  shareCount: number
  adWatchCount: number
}

export function getSettings(): AppSettings {
  try {
    const data = uni.getStorageSync(STORAGE_KEYS.SETTINGS)
    return data ? JSON.parse(data) : { shareCount: 0, adWatchCount: 0 }
  } catch {
    return { shareCount: 0, adWatchCount: 0 }
  }
}

export function saveSettings(settings: AppSettings): void {
  uni.setStorageSync(STORAGE_KEYS.SETTINGS, JSON.stringify(settings))
}

export function initFirstUse(): void {
  const settings = getSettings()
  if (!settings.firstUseDate) {
    settings.firstUseDate = Date.now()
    saveSettings(settings)
  }
}

export function incrementShareCount(): void {
  const settings = getSettings()
  settings.shareCount++
  saveSettings(settings)
}

export function incrementAdWatchCount(): void {
  const settings = getSettings()
  settings.adWatchCount++
  saveSettings(settings)
}

// === 打卡日历 ===

export interface CheckinData {
  dates: string[]  // 'YYYY-MM-DD' 格式
}

/** 获取所有打卡日期 */
export function getCheckinDates(): string[] {
  try {
    const data = uni.getStorageSync(STORAGE_KEYS.CHECKIN)
    if (data) {
      const parsed: CheckinData = JSON.parse(data)
      return parsed.dates || []
    }
    return []
  } catch {
    return []
  }
}

/** 今日打卡（保存笔记时自动调用） */
export function checkinToday(): void {
  const dates = getCheckinDates()
  const today = new Date()
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
  if (!dates.includes(todayStr)) {
    dates.push(todayStr)
    uni.setStorageSync(STORAGE_KEYS.CHECKIN, JSON.stringify({ dates }))
  }
}

/** 获取本周打卡天数（周一开始） */
export function getWeekCheckinCount(): number {
  const dates = getCheckinDates()
  const now = new Date()
  const dayOfWeek = now.getDay() === 0 ? 7 : now.getDay() // 周一=1, 周日=7
  const monday = new Date(now)
  monday.setDate(now.getDate() - dayOfWeek + 1)
  monday.setHours(0, 0, 0, 0)

  return dates.filter(d => {
    const date = new Date(d + 'T00:00:00')
    return date >= monday && date <= now
  }).length
}

/** 获取某月在哪些天有打卡 */
export function getMonthCheckinDays(year: number, month: number): number[] {
  const dates = getCheckinDates()
  const prefix = `${year}-${String(month).padStart(2, '0')}-`
  return dates
    .filter(d => d.startsWith(prefix))
    .map(d => parseInt(d.split('-')[2]))
}

// === 每日语录 ===

const dailyQuotes = [
  '今天也是值得记录的一天 ✨',
  '慢慢来，比较快 🌿',
  '生活不止眼前的苟且 🌸',
  '你的文字，值得被温柔对待 📝',
  '每一天都是崭新的开始 🌅',
  '记录生活的小确幸 ☀️',
  '温柔对待自己 🍃',
  '慢慢记录，细细品味 ☕',
]

export function getDailyQuote(): string {
  const dayIndex = Math.floor(Date.now() / 86400000) % dailyQuotes.length
  return dailyQuotes[dayIndex]
}
