/**
 * 模板 Canvas 2D 绘制引擎
 * 配置驱动，21 套模板统一渲染
 */

export interface DrawOptions {
  canvas: any           // Canvas 2D 上下文
  width: number         // 画布宽 px
  height: number        // 画布高 px
  content: string       // 文字内容
  imagePaths?: string[] // 图片路径
  animalId: string
  templateId: string
  fontId: string
  fontSize: number      // px
}

// 通用字体映射（系统字体，无需下载）
function getFontFamily(fontId: string): string {
  const map: Record<string, string> = {
    warm_kai: 'serif',
    round_cream: 'cursive',
    serif_jp: 'serif',
    art_handwrite: 'cursive',
    biz_hei: 'sans-serif',
    thin_hei: 'sans-serif',
  }
  return map[fontId] || 'sans-serif'
}

// ========== 绘制工具函数 ==========

function drawBackground(ctx: any, w: number, h: number, color: string) {
  ctx.fillStyle = color
  ctx.fillRect(0, 0, w, h)
}

/** 绘制网格线 */
function drawGrid(ctx: any, w: number, h: number, color: string, gap: number) {
  ctx.strokeStyle = color
  ctx.lineWidth = 0.5
  for (let y = gap; y < h; y += gap) {
    ctx.beginPath()
    ctx.moveTo(0, y)
    ctx.lineTo(w, y)
    ctx.stroke()
  }
}

/** 绘制横线 */
function drawLines(ctx: any, w: number, h: number, color: string, gap: number, padding: number) {
  ctx.strokeStyle = color
  ctx.lineWidth = 0.8
  for (let y = padding + gap; y < h - padding; y += gap) {
    ctx.beginPath()
    ctx.moveTo(padding, y)
    ctx.lineTo(w - padding, y)
    ctx.stroke()
  }
}

/** 绘制圆角矩形 */
function roundRect(ctx: any, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arcTo(x + w, y, x + w, y + r, r)
  ctx.lineTo(x + w, y + h - r)
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r)
  ctx.lineTo(x + r, y + h)
  ctx.arcTo(x, y + h, x, y + h - r, r)
  ctx.lineTo(x, y + r)
  ctx.arcTo(x, y, x + r, y, r)
  ctx.closePath()
}

/** 绘制边框装饰 */
function drawBorder(ctx: any, w: number, h: number, color: string, width: number, margin: number) {
  ctx.strokeStyle = color
  ctx.lineWidth = width
  ctx.strokeRect(margin, margin, w - margin * 2, h - margin * 2)
}

/** 绘制双线边框 */
function drawDoubleBorder(ctx: any, w: number, h: number, color: string, margin: number) {
  ctx.strokeStyle = color
  ctx.lineWidth = 1
  ctx.strokeRect(margin, margin, w - margin * 2, h - margin * 2)
  ctx.strokeRect(margin + 4, margin + 4, w - margin * 2 - 8, h - margin * 2 - 8)
}

/** 绘制虚线边框 */
function drawDashedBorder(ctx: any, w: number, h: number, color: string, margin: number) {
  ctx.strokeStyle = color
  ctx.lineWidth = 1.5
  ctx.setLineDash([8, 4])
  ctx.strokeRect(margin, margin, w - margin * 2, h - margin * 2)
  ctx.setLineDash([])
}

/** 绘制水印 */
function drawWatermark(ctx: any, w: number, h: number) {
  ctx.save()
  ctx.globalAlpha = 0.15
  ctx.font = '12px sans-serif'
  ctx.fillStyle = '#999'
  ctx.textAlign = 'right'
  ctx.fillText('FineGrain', w - 16, h - 16)
  ctx.restore()
}

/** 文字自动换行绘制 */
function drawText(ctx: any, text: string, x: number, y: number, maxWidth: number, lineHeight: number, fontStr: string, color: string): number {
  ctx.font = fontStr
  ctx.fillStyle = color
  ctx.textAlign = 'left'
  ctx.textBaseline = 'top'

  let currentY = y
  const paragraphs = text.split('\n')

  for (const para of paragraphs) {
    if (!para.trim()) {
      currentY += lineHeight * 0.6
      continue
    }
    let line = ''
    for (let i = 0; i < para.length; i++) {
      const testLine = line + para[i]
      const metrics = ctx.measureText(testLine)
      if (metrics.width > maxWidth && line.length > 0) {
        ctx.fillText(line, x, currentY)
        line = para[i]
        currentY += lineHeight
      } else {
        line = testLine
      }
    }
    if (line) {
      ctx.fillText(line, x, currentY)
      currentY += lineHeight
    }
  }
  return currentY
}

// ========== 21 套模板绘制 ==========

// --- 安安（日系） ---

function drawAnanWood(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FFF9F5')
  // 原木条纹
  ctx.globalAlpha = 0.06
  for (let y = 0; y < h; y += 40) {
    ctx.fillStyle = y % 80 === 0 ? '#D4A574' : '#C9956A'
    ctx.fillRect(0, y, w, 40)
  }
  ctx.globalAlpha = 1
  drawBorder(ctx, w, h, '#E8D5C4', 1, 32)
}

function drawAnanGrid(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FFFCF8')
  drawGrid(ctx, w, h, 'rgba(200,180,160,0.15)', 28)
  drawBorder(ctx, w, h, '#E8D5C4', 0.5, 20)
}

function drawAnanMorandi(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#EDE5DA')
  // 底部渐变装饰
  const grad = ctx.createLinearGradient(0, h - 80, 0, h)
  grad.addColorStop(0, 'rgba(201,168,138,0)')
  grad.addColorStop(1, 'rgba(201,168,138,0.15)')
  ctx.fillStyle = grad
  ctx.fillRect(0, h - 80, w, 80)
}

// --- 贴贴（森系） ---

function drawTietieTape(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F2F8F2')
  // 顶部和底部胶带
  ctx.fillStyle = 'rgba(168,200,160,0.5)'
  ctx.fillRect(0, 0, w, 24)
  ctx.fillRect(0, h - 24, w, 24)
  // 胶带纹理
  ctx.fillStyle = 'rgba(123,163,126,0.15)'
  ctx.fillRect(0, 0, w, 24)
  ctx.fillRect(0, h - 24, w, 24)
  // 两侧竖线
  ctx.strokeStyle = 'rgba(123,163,126,0.2)'
  ctx.lineWidth = 2
  ctx.setLineDash([6, 6])
  ctx.beginPath()
  ctx.moveTo(24, 28)
  ctx.lineTo(24, h - 28)
  ctx.moveTo(w - 24, 28)
  ctx.lineTo(w - 24, h - 28)
  ctx.stroke()
  ctx.setLineDash([])
}

function drawTietieBotanical(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F5FAF5')
  // 干花肌理：散落小圆点
  ctx.globalAlpha = 0.08
  const seed = 42
  for (let i = 0; i < 30; i++) {
    const px = ((seed * (i + 1) * 7) % w)
    const py = ((seed * (i + 1) * 13) % h)
    const r = 3 + (i % 4) * 2
    ctx.fillStyle = i % 2 === 0 ? '#7BA37E' : '#A8C8A0'
    ctx.beginPath()
    ctx.arc(px, py, r, 0, Math.PI * 2)
    ctx.fill()
  }
  ctx.globalAlpha = 1
  drawDoubleBorder(ctx, w, h, '#A8C8A0', 20)
}

function drawTietieTorn(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F5FAF5')
  // 撕边效果：不规则边缘
  ctx.strokeStyle = 'rgba(168,200,160,0.4)'
  ctx.lineWidth = 2
  ctx.beginPath()
  // 上边
  ctx.moveTo(0, 20)
  for (let x = 0; x < w; x += 8) {
    ctx.lineTo(x, 18 + Math.sin(x * 0.3) * 4)
  }
  ctx.stroke()
  // 下边
  ctx.beginPath()
  ctx.moveTo(0, h - 20)
  for (let x = 0; x < w; x += 8) {
    ctx.lineTo(x, h - 18 + Math.sin(x * 0.3) * 4)
  }
  ctx.stroke()
}

// --- 办办（商务） ---

function drawBanbanLines(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FDF8F0')
  drawLines(ctx, w, h, 'rgba(139,115,85,0.15)', 32, 48)
  // 左侧红线
  ctx.strokeStyle = 'rgba(200,80,80,0.15)'
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.moveTo(56, 20)
  ctx.lineTo(56, h - 20)
  ctx.stroke()
}

function drawBanbanCoffee(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F5EDE3')
  // 微妙纸张纹理
  ctx.globalAlpha = 0.03
  for (let y = 0; y < h; y += 20) {
    for (let x = 0; x < w; x += 20) {
      if ((x + y) % 40 === 0) {
        ctx.fillStyle = '#8B7355'
        ctx.fillRect(x, y, 20, 20)
      }
    }
  }
  ctx.globalAlpha = 1
  drawBorder(ctx, w, h, '#C9A88A', 0.8, 24)
}

function drawBanbanTodo(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FDF8F0')
  drawBorder(ctx, w, h, '#B8956A', 1.5, 20)
  // 复选框装饰
  ctx.strokeStyle = 'rgba(184,149,106,0.3)'
  ctx.lineWidth = 1
  for (let y = 56; y < h - 40; y += 36) {
    roundRect(ctx, 32, y, 14, 14, 2)
    ctx.stroke()
    // 横线
    ctx.beginPath()
    ctx.moveTo(54, y + 8)
    ctx.lineTo(w - 32, y + 8)
    ctx.strokeStyle = 'rgba(184,149,106,0.1)'
    ctx.stroke()
    ctx.strokeStyle = 'rgba(184,149,106,0.3)'
  }
}

// --- 墨墨（古风） ---

function drawMomoXuan(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F5EDE0')
  // 宣纸纹理
  ctx.globalAlpha = 0.04
  for (let y = 0; y < h; y += 6) {
    for (let x = 0; x < w; x += 6) {
      const v = Math.random() * 0.5
      ctx.fillStyle = v > 0.3 ? '#8B7355' : '#D4C4A8'
      ctx.fillRect(x, y, 2, 2)
    }
  }
  ctx.globalAlpha = 1
}

function drawMomoSeal(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F5EDE0')
  drawBorder(ctx, w, h, '#6B4226', 1, 28)
  // 右下角印章
  ctx.save()
  ctx.fillStyle = 'rgba(139,0,0,0.15)'
  roundRect(ctx, w - 72, h - 72, 40, 40, 4)
  ctx.fill()
  ctx.restore()
  // 顶部细线
  ctx.strokeStyle = 'rgba(107,66,38,0.2)'
  ctx.lineWidth = 0.5
  ctx.beginPath()
  ctx.moveTo(28, 44)
  ctx.lineTo(w - 28, 44)
  ctx.stroke()
}

function drawMomoScroll(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F0E6D4')
  // 卷轴上下轴
  ctx.fillStyle = '#8B7355'
  ctx.fillRect(16, 8, w - 32, 12)
  ctx.fillRect(16, h - 20, w - 32, 12)
  // 轴头
  ctx.fillStyle = '#6B4226'
  ctx.beginPath()
  ctx.arc(16, 14, 8, 0, Math.PI * 2)
  ctx.arc(w - 16, 14, 8, 0, Math.PI * 2)
  ctx.arc(16, h - 14, 8, 0, Math.PI * 2)
  ctx.arc(w - 16, h - 14, 8, 0, Math.PI * 2)
  ctx.fill()
  // 内部浅色区域
  ctx.fillStyle = '#F5EDE0'
  ctx.fillRect(20, 22, w - 40, h - 44)
}

// --- 邮邮（旅行） ---

function drawYouyouPolaroid(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FDF8EE')
  // 拍立得白边框
  const m = 24
  ctx.fillStyle = '#FFFFFF'
  roundRect(ctx, m, m, w - m * 2, h - m * 2 - 48, 4)
  ctx.fill()
  ctx.shadowColor = 'rgba(0,0,0,0.08)'
  ctx.shadowBlur = 8
  roundRect(ctx, m, m, w - m * 2, h - m * 2 - 48, 4)
  ctx.fill()
  ctx.shadowColor = 'transparent'
  ctx.shadowBlur = 0
  // 底部留白更多（拍立得签名区）
}

function drawYouyouPostmark(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FDF8EE')
  drawBorder(ctx, w, h, '#C4A35A', 1, 20)
  // 邮戳圆圈
  ctx.strokeStyle = 'rgba(139,115,85,0.15)'
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.arc(w - 60, 60, 28, 0, Math.PI * 2)
  ctx.stroke()
  // 邮戳横线
  ctx.beginPath()
  ctx.moveTo(w - 90, 60)
  ctx.lineTo(w - 30, 60)
  ctx.stroke()
  ctx.font = '10px serif'
  ctx.fillStyle = 'rgba(139,115,85,0.2)'
  ctx.textAlign = 'center'
  ctx.fillText('✉', w - 60, 55)
}

function drawYouyouTicket(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FDF8EE')
  drawBorder(ctx, w, h, '#C4A35A', 1, 16)
  // 虚线分割
  ctx.strokeStyle = 'rgba(196,163,90,0.3)'
  ctx.lineWidth = 1
  ctx.setLineDash([6, 4])
  ctx.beginPath()
  ctx.moveTo(16, h * 0.3)
  ctx.lineTo(w - 16, h * 0.3)
  ctx.moveTo(16, h * 0.7)
  ctx.lineTo(w - 16, h * 0.7)
  ctx.stroke()
  ctx.setLineDash([])
  // 左侧小圆缺口
  ctx.fillStyle = '#FDF8EE'
  ctx.beginPath()
  ctx.arc(0, h * 0.3, 8, 0, Math.PI * 2)
  ctx.arc(0, h * 0.7, 8, 0, Math.PI * 2)
  ctx.fill()
  // 右侧
  ctx.beginPath()
  ctx.arc(w, h * 0.3, 8, 0, Math.PI * 2)
  ctx.arc(w, h * 0.7, 8, 0, Math.PI * 2)
  ctx.fill()
}

// --- 点点（像素） ---

function drawDiandianWindow(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#2D3748')
  // 像素窗口
  ctx.fillStyle = '#4A5568'
  ctx.fillRect(16, 16, w - 32, h - 32)
  // 窗口标题栏
  ctx.fillStyle = '#63B3ED'
  ctx.fillRect(16, 16, w - 32, 24)
  // 小圆点
  ctx.fillStyle = '#E53E3E'
  ctx.fillRect(24, 22, 10, 10)
  ctx.fillStyle = '#ECC94B'
  ctx.fillRect(40, 22, 10, 10)
  ctx.fillStyle = '#48BB78'
  ctx.fillRect(56, 22, 10, 10)
}

function drawDiandianDark(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#1A202C')
  // 底部扫描线效果
  ctx.globalAlpha = 0.03
  for (let y = 0; y < h; y += 3) {
    ctx.fillStyle = '#63B3ED'
    ctx.fillRect(0, y, w, 1)
  }
  ctx.globalAlpha = 1
}

function drawDiandianPixel(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#F7FAFC')
  // 像素格边框
  ctx.fillStyle = '#4A5568'
  const bs = 6  // 像素块大小
  for (let x = 12; x < w - 12; x += bs * 2) {
    ctx.fillRect(x, 12, bs, bs)
    ctx.fillRect(x, h - 12 - bs, bs, bs)
  }
  for (let y = 12; y < h - 12; y += bs * 2) {
    ctx.fillRect(12, y, bs, bs)
    ctx.fillRect(w - 12 - bs, y, bs, bs)
  }
}

// --- 查查（极简） ---

function drawChachaWhite(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FFFFFF')
  // 极简：只有一条极细的底部线
  ctx.strokeStyle = 'rgba(0,0,0,0.04)'
  ctx.lineWidth = 0.5
  ctx.beginPath()
  ctx.moveTo(32, h - 32)
  ctx.lineTo(w - 32, h - 32)
  ctx.stroke()
}

function drawChachaLines(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#FFFFFF')
  // 细线条公文风
  ctx.strokeStyle = 'rgba(160,174,192,0.2)'
  ctx.lineWidth = 0.5
  ctx.beginPath()
  ctx.moveTo(28, 40)
  ctx.lineTo(w - 28, 40)
  ctx.moveTo(28, h - 40)
  ctx.lineTo(w - 28, h - 40)
  ctx.stroke()
  // 左侧竖线
  ctx.strokeStyle = 'rgba(160,174,192,0.15)'
  ctx.beginPath()
  ctx.moveTo(28, 40)
  ctx.lineTo(28, h - 40)
  ctx.stroke()
}

function drawChachaGray(ctx: any, w: number, h: number) {
  drawBackground(ctx, w, h, '#EDF2F7')
  // 低饱和：什么都不加，纯净
}

// ========== 模板绘制分发 ==========

const templateDrawers: Record<string, (ctx: any, w: number, h: number) => void> = {
  // 安安
  anan_wood: drawAnanWood,
  anan_grid: drawAnanGrid,
  anan_morandi: drawAnanMorandi,
  // 贴贴
  tietie_tape: drawTietieTape,
  tietie_botanical: drawTietieBotanical,
  tietie_torn: drawTietieTorn,
  // 办办
  banban_lines: drawBanbanLines,
  banban_coffee: drawBanbanCoffee,
  banban_todo: drawBanbanTodo,
  // 墨墨
  momo_xuan: drawMomoXuan,
  momo_seal: drawMomoSeal,
  momo_scroll: drawMomoScroll,
  // 邮邮
  youyou_polaroid: drawYouyouPolaroid,
  youyou_postmark: drawYouyouPostmark,
  youyou_ticket: drawYouyouTicket,
  // 点点
  diandian_window: drawDiandianWindow,
  diandian_dark: drawDiandianDark,
  diandian_pixel: drawDiandianPixel,
  // 查查
  chacha_white: drawChachaWhite,
  chacha_lines: drawChachaLines,
  chacha_gray: drawChachaGray,
}

// ========== 各模板的文字颜色 ==========

const templateTextColors: Record<string, string> = {
  anan_wood: '#5C4A3A',
  anan_grid: '#5C4A3A',
  anan_morandi: '#5C4A3A',
  tietie_tape: '#3A5C3C',
  tietie_botanical: '#3A5C3C',
  tietie_torn: '#3A5C3C',
  banban_lines: '#4A3A2A',
  banban_coffee: '#4A3A2A',
  banban_todo: '#4A3A2A',
  momo_xuan: '#3D2B1F',
  momo_seal: '#3D2B1F',
  momo_scroll: '#3D2B1F',
  youyou_polaroid: '#5C4B2E',
  youyou_postmark: '#5C4B2E',
  youyou_ticket: '#5C4B2E',
  diandian_window: '#E2E8F0',
  diandian_dark: '#63B3ED',
  diandian_pixel: '#2D3748',
  chacha_white: '#1A202C',
  chacha_lines: '#1A202C',
  chacha_gray: '#2D3748',
}

// ========== 各模板的文字边距 ==========

interface TemplatePadding {
  top: number
  left: number
  right: number
  bottom: number
}

const templatePaddings: Record<string, TemplatePadding> = {
  anan_wood: { top: 48, left: 48, right: 48, bottom: 48 },
  anan_grid: { top: 36, left: 36, right: 36, bottom: 36 },
  anan_morandi: { top: 44, left: 44, right: 44, bottom: 44 },
  tietie_tape: { top: 40, left: 40, right: 40, bottom: 40 },
  tietie_botanical: { top: 40, left: 36, right: 36, bottom: 40 },
  tietie_torn: { top: 36, left: 40, right: 40, bottom: 36 },
  banban_lines: { top: 56, left: 64, right: 40, bottom: 40 },
  banban_coffee: { top: 40, left: 40, right: 40, bottom: 40 },
  banban_todo: { top: 44, left: 60, right: 40, bottom: 44 },
  momo_xuan: { top: 44, left: 44, right: 44, bottom: 44 },
  momo_seal: { top: 56, left: 44, right: 44, bottom: 60 },
  momo_scroll: { top: 36, left: 40, right: 40, bottom: 36 },
  youyou_polaroid: { top: 40, left: 40, right: 40, bottom: 72 },
  youyou_postmark: { top: 44, left: 36, right: 36, bottom: 44 },
  youyou_ticket: { top: 44, left: 36, right: 36, bottom: 44 },
  diandian_window: { top: 52, left: 32, right: 32, bottom: 32 },
  diandian_dark: { top: 40, left: 36, right: 36, bottom: 40 },
  diandian_pixel: { top: 32, left: 32, right: 32, bottom: 32 },
  chacha_white: { top: 44, left: 44, right: 44, bottom: 48 },
  chacha_lines: { top: 52, left: 44, right: 44, bottom: 52 },
  chacha_gray: { top: 44, left: 44, right: 44, bottom: 44 },
}

/**
 * 主绘制入口
 */
export function drawTemplate(options: DrawOptions): void {
  const { canvas, width, height, content, animalId, templateId, fontId, fontSize, imagePaths } = options
  const ctx = canvas.getContext('2d')

  // 1. 绘制模板背景
  const drawer = templateDrawers[templateId]
  if (drawer) {
    drawer(ctx, width, height)
  } else {
    drawBackground(ctx, width, height, '#FFF9F5')
  }

  // 2. 获取文字配置
  const textColor = templateTextColors[templateId] || '#333333'
  const padding = templatePaddings[templateId] || { top: 44, left: 44, right: 44, bottom: 44 }
  const fontFamily = getFontFamily(fontId)
  const fontStr = `${fontSize}px ${fontFamily}`
  const lineHeight = fontSize * 1.8
  const maxWidth = width - padding.left - padding.right

  // 3. 绘制图片
  let textStartY = padding.top
  if (imagePaths && imagePaths.length > 0) {
    const imgSize = Math.min(120, (maxWidth - 16) / Math.min(imagePaths.length, 3) - 8)
    const totalImgWidth = imagePaths.length * (imgSize + 8) - 8
    let imgX = padding.left
    for (let i = 0; i < Math.min(imagePaths.length, 3); i++) {
      try {
        ctx.drawImage(imagePaths[i], imgX, textStartY, imgSize, imgSize)
      } catch {}
      imgX += imgSize + 8
    }
    textStartY += imgSize + 16
  }

  // 4. 绘制文字
  drawText(ctx, content, padding.left, textStartY, maxWidth, lineHeight, fontStr, textColor)

  // 5. 水印
  drawWatermark(ctx, width, height)
}
