/**
 * 匹配页 - 修复版
 * 使用双方维度差值的加权得分来匹配 25 种关系
 */

const { calcSimilarity, normalize, getMainType, DIMENSION_MAP } = require('../../utils/cpti')
const { drawMatchPoster, savePoster } = require('../../utils/poster')
const relations = require('../../data/relations')

Page({
  data: {
    inputId: '',
    myId: '',
    matched: false,
    relation: {},
    similarity: 0,
    myType: '',
    taType: '',
  },

  myScore: null,

  onInput(e) {
    this.setData({ inputId: e.detail.value.toUpperCase() })
  },

  onMyInput(e) {
    this.setData({ myId: e.detail.value.toUpperCase() })
  },

  loadMyResult() {
    const db = wx.cloud.database()
    wx.showLoading({ title: '加载中' })
    db.collection('results').where({
      cpId: this.data.myId,
    }).get().then(res => {
      wx.hideLoading()
      if (res.data.length === 0) {
        wx.showToast({ title: '未找到结果', icon: 'none' })
        return
      }
      this.myScore = res.data[0].score
      wx.showToast({ title: '加载成功', icon: 'success' })
    }).catch(() => {
      wx.hideLoading()
      wx.showToast({ title: '加载失败', icon: 'none' })
    })
  },

  /**
   * 计算关系匹配分数（-100 ~ 100）
   * 基于维度差异的加权算法：
   * - 高相似 → 正高分（90-100）
   * - 互补型 → 中等正分
   * - 差异大 → 负分
   */
  calcRelationScore(myScore, taScore) {
    const keys = ['C', 'G', 'L', 'S', 'T']
    let totalDiff = 0

    for (let k of keys) {
      totalDiff += Math.abs(myScore[k] - taScore[k])
    }

    const avgDiff = totalDiff / keys.length

    // avgDiff 范围 0-100
    // 映射到 -60 ~ 100，使分数更分散
    let score = 100 - avgDiff * 1.6

    // 互补维度加负分（推入负区间）
    let complementCount = 0
    for (let k of keys) {
      if ((myScore[k] > 65 && taScore[k] < 35) || (myScore[k] < 35 && taScore[k] > 65)) {
        complementCount++
      }
    }
    score -= complementCount * 6

    // 主维度不同再减分
    const myMain = getMainType(myScore)
    const taMain = getMainType(taScore)
    if (myMain !== taMain) {
      score -= 3
    }

    return Math.max(-100, Math.min(100, Math.round(score)))
  },

  doMatch() {
    if (!this.myScore) {
      wx.showToast({ title: '请先加载自己的结果', icon: 'none' })
      return
    }

    const db = wx.cloud.database()
    wx.showLoading({ title: '匹配中' })

    db.collection('results').where({
      cpId: this.data.inputId,
    }).get().then(res => {
      wx.hideLoading()
      if (res.data.length === 0) {
        wx.showToast({ title: '未找到 TA 的结果', icon: 'none' })
        return
      }

      const taScore = res.data[0].score
      const similarity = calcSimilarity(this.myScore, taScore)
      const myType = DIMENSION_MAP[getMainType(this.myScore)]
      const taType = DIMENSION_MAP[getMainType(taScore)]

      // 用关系分数匹配
      const relationScore = this.calcRelationScore(this.myScore, taScore)
      const relation = matchRelation(relationScore, relations)

      this.setData({
        matched: true,
        relation,
        similarity,
        myType,
        taType,
      })

      // 记录收集进度到本地
      const unlocked = wx.getStorageSync('unlockedRelationIds') || []
      if (!unlocked.includes(relation.id)) {
        unlocked.push(relation.id)
        wx.setStorageSync('unlockedRelationIds', unlocked)
      }
    }).catch(() => {
      wx.hideLoading()
      wx.showToast({ title: '匹配失败', icon: 'none' })
    })
  },

  saveMatchPoster() {
    if (!this.data.matched) return
    wx.showLoading({ title: '生成海报...' })
    const query = wx.createSelectorQuery()
    query.select('#matchPosterCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res || !res[0]) {
          wx.hideLoading()
          return
        }
        const canvas = res[0].node
        drawMatchPoster(canvas, {
          width: 375,
          height: 667,
          relation: this.data.relation,
          similarity: this.data.similarity,
          myType: this.data.myType,
          taType: this.data.taType,
        })
        setTimeout(() => {
          savePoster(canvas, 375, 667)
            .then(() => wx.hideLoading())
            .catch(() => { wx.hideLoading(); wx.showToast({ title: '保存失败', icon: 'none' }) })
        }, 300)
      })
  },

  goHome() {
    wx.reLaunch({ url: '/pages/index/index' })
  },

  onShareAppMessage() {
    return {
      title: '我们的关系匹配度是' + this.data.similarity + '%，快来测测你的',
      path: '/pages/index/index',
    }
  },
})
