<template>
  <view class="page">
    <view class="content">
      <text class="title">用户协议</text>
      <text class="update-date">更新日期：2026年4月20日</text>

      <text class="section-title">一、服务说明</text>
      <text class="paragraph">「轻治愈动物笔记」是一款由个人开发者开发的微信小程序，提供治愈系手账笔记功能。本服务按"现状"提供，开发者不对服务做任何明示或暗示的保证。</text>

      <text class="section-title">二、使用规范</text>
      <text class="paragraph">1. 您应合法、合规使用本小程序，不得利用本服务从事违法违规活动。\n2. 您对通过本服务创建的所有内容负责。\n3. 请勿尝试破解、反编译或以其他方式干扰小程序正常运行。</text>

      <text class="section-title">三、知识产权</text>
      <text class="paragraph">1. 本小程序中的所有角色形象、文案、模板设计均为原创作品，受知识产权法保护。\n2. 使用的字体均为免费商用授权字体。\n3. 未经开发者许可，不得复制、传播或商业使用本小程序中的任何素材。</text>

      <text class="section-title">四、免责声明</text>
      <text class="paragraph">1. 因本地存储特性，设备损坏、微信缓存清理等可能导致数据丢失，开发者不承担数据恢复责任。\n2. 本小程序依赖微信平台运行，因微信平台政策调整导致的服务变更，开发者不承担责任。</text>

      <text class="section-title">五、协议修改</text>
      <text class="paragraph">开发者有权随时修改本协议条款，修改后继续使用本服务即视为同意修改后的条款。</text>

      <text class="section-title">六、联系我们</text>
      <text class="paragraph">如您对本协议有任何疑问，请通过微信小程序平台联系开发者。</text>
    </view>
  </view>
</template>

<style scoped>
.page { min-height: 100vh; background: #FFF9F5; }
.content { padding: 30rpx; }
.title { font-size: 36rpx; font-weight: bold; color: #333; display: block; margin-bottom: 12rpx; }
.update-date { font-size: 24rpx; color: #999; display: block; margin-bottom: 30rpx; }
.section-title { font-size: 30rpx; font-weight: 600; color: #333; display: block; margin: 30rpx 0 16rpx; }
.paragraph { font-size: 28rpx; color: #555; line-height: 1.8; display: block; margin-bottom: 12rpx; }
</style>
