<template>
  <view class="page">
    <text class="title">选择你的动物伙伴</text>

    <view class="animal-list">
      <view
        v-for="animal in animals"
        :key="animal.id"
        class="animal-card"
        :class="{ locked: !isUnlocked(animal.id), active: selectedId === animal.id }"
        :style="selectedId === animal.id ? { borderColor: animal.style.primaryColor, background: animal.style.secondaryColor } : {}"
        @tap="selectAnimal(animal)"
      >
        <view class="card-left">
          <view class="card-avatar" :style="{ background: animal.style.bgColor }">
            <text class="avatar-emoji">{{ getEmoji(animal.species) }}</text>
            <view v-if="!isUnlocked(animal.id)" class="lock-badge">🔒</view>
          </view>
          <view class="card-info">
            <text class="card-name">{{ animal.name }}</text>
            <text class="card-species">{{ animal.species }}</text>
            <text class="card-style">{{ animal.styleName }}</text>
          </view>
        </view>
        <view class="card-right">
          <view class="color-dot" :style="{ background: animal.style.primaryColor }" />
          <text v-if="isUnlocked(animal.id) && selectedId === animal.id" class="card-check">✓</text>
          <text v-else-if="isUnlocked(animal.id)" class="card-select">选择</text>
        </view>
      </view>
    </view>

    <!-- 选中动物的模板预览 -->
    <view v-if="selectedAnimal" class="preview-section">
      <text class="preview-title">{{ selectedAnimal.storageBox }}</text>
      <text class="preview-loading">{{ selectedAnimal.loadingText }}</text>
      <view class="template-row">
        <view v-for="tpl in selectedAnimal.templates" :key="tpl.id" class="template-chip"
          :style="{ background: selectedAnimal.style.secondaryColor, borderColor: selectedAnimal.style.primaryColor }">
          <text class="tpl-name">{{ tpl.name }}</text>
        </view>
      </view>
      <!-- 推荐字体 -->
      <view class="font-hint">
        <text class="font-hint-text">推荐字体：{{ recommendedFontName }}</text>
      </view>
    </view>

    <!-- 底部开始记录按钮 -->
    <view class="bottom-action" v-if="selectedAnimal && isUnlocked(selectedAnimal.id)">
      <view class="start-btn" :style="{ background: `linear-gradient(135deg, ${selectedAnimal.style.primaryColor}, ${selectedAnimal.style.accentColor})` }" @tap="startNote">
        <text class="start-text">开始记录</text>
      </view>
    </view>

    <!-- 解锁弹窗 -->
    <view class="modal-overlay" v-if="unlockTarget" @tap="unlockTarget = null">
      <view class="unlock-modal" @tap.stop>
        <text class="unlock-emoji">{{ getEmoji(unlockTarget.species) }}</text>
        <text class="unlock-name">{{ unlockTarget.name }}</text>
        <text class="unlock-style">{{ unlockTarget.styleName }}</text>
        <text class="unlock-hint">选择一种方式解锁</text>
        <view class="unlock-actions">
          <view class="unlock-btn share" @tap="unlockByShare">
            <text>📤 分享给好友解锁</text>
          </view>
          <view class="unlock-btn ad" @tap="unlockByAd">
            <text>🎬 观看广告解锁</text>
          </view>
        </view>
        <view class="unlock-cancel" @tap="unlockTarget = null">
          <text>稍后再说</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { animals, getAnimalEmoji, type AnimalConfig } from '../../templates/animals'
import { getFont } from '../../templates/fonts'
import { isAnimalUnlocked, unlockAnimal } from '../../utils/storage'
import { getCurrentAnimalId, setCurrentAnimalId } from '../../utils/animalState'

const selectedId = ref('anan')
const selectedAnimal = ref<AnimalConfig>(animals[0])
const unlockTarget = ref<AnimalConfig | null>(null)

onMounted(() => {
  const currentId = getCurrentAnimalId()
  selectedId.value = currentId
  const animal = animals.find(a => a.id === currentId)
  if (animal) selectedAnimal.value = animal
})

function getEmoji(species: string) { return getAnimalEmoji(species) }
function isUnlocked(id: string) { return isAnimalUnlocked(id) }

const recommendedFontName = computed(() => {
  const font = getFont(selectedAnimal.value?.recommendedFont || '')
  return font?.name || '默认'
})

function selectAnimal(animal: AnimalConfig) {
  if (!isAnimalUnlocked(animal.id)) {
    unlockTarget.value = animal
    return
  }
  selectedId.value = animal.id
  selectedAnimal.value = animal
  setCurrentAnimalId(animal.id)
}

function startNote() {
  uni.navigateTo({ url: `/pages/editor/index?animalId=${selectedId.value}` })
}

async function unlockByShare() {
  if (!unlockTarget.value) return
  try {
    await uni.shareAppMessage({
      title: `轻治愈动物笔记 - 用${unlockTarget.value.name}记录生活`,
      path: '/pages/index/index',
    })
    unlockAnimal(unlockTarget.value.id)
    unlockTarget.value = null
    uni.showToast({ title: '解锁成功！', icon: 'success' })
  } catch {
    // 用户取消分享
  }
}

function unlockByAd() {
  if (!unlockTarget.value) return
  // TODO: 接入微信流量主激励视频广告
  // uni.createRewardedVideoAd({...}).show()
  uni.showToast({ title: '广告功能即将上线', icon: 'none' })
}
</script>

<style scoped>
.page { min-height: 100vh; background: #FFF9F5; padding: 30rpx 30rpx 160rpx; }
.title { font-size: 36rpx; font-weight: bold; color: #333; display: block; margin-bottom: 30rpx; }

.animal-list { display: flex; flex-direction: column; gap: 20rpx; }
.animal-card {
  display: flex; align-items: center; justify-content: space-between;
  background: #fff; border-radius: 16rpx; padding: 24rpx;
  border: 2rpx solid #e8e8e8; transition: all 0.2s;
}
.animal-card.active { border-width: 3rpx; }
.animal-card.locked { opacity: 0.5; }
.card-left { display: flex; align-items: center; gap: 20rpx; }
.card-avatar {
  width: 80rpx; height: 80rpx; border-radius: 50%;
  display: flex; align-items: center; justify-content: center; position: relative;
}
.avatar-emoji { font-size: 40rpx; }
.lock-badge { position: absolute; bottom: -4rpx; right: -4rpx; font-size: 24rpx; }
.card-info { display: flex; flex-direction: column; }
.card-name { font-size: 30rpx; font-weight: 600; color: #333; }
.card-species { font-size: 24rpx; color: #999; }
.card-style { font-size: 22rpx; color: #C9A88A; margin-top: 4rpx; }
.card-right { display: flex; align-items: center; gap: 12rpx; }
.color-dot { width: 24rpx; height: 24rpx; border-radius: 50%; }
.card-check { color: #07C160; font-size: 32rpx; font-weight: bold; }
.card-select { font-size: 24rpx; color: #C9A88A; }

.preview-section {
  margin-top: 36rpx; padding: 30rpx; background: #fff;
  border-radius: 16rpx; text-align: center;
}
.preview-title { font-size: 30rpx; font-weight: 600; color: #333; display: block; }
.preview-loading { font-size: 24rpx; color: #999; display: block; margin: 16rpx 0; }
.template-row { display: flex; gap: 12rpx; justify-content: center; margin-top: 20rpx; flex-wrap: wrap; }
.template-chip {
  padding: 12rpx 24rpx; border-radius: 20rpx;
  border: 1rpx solid;
}
.tpl-name { font-size: 24rpx; color: #666; }
.font-hint { margin-top: 16rpx; }
.font-hint-text { font-size: 22rpx; color: #aaa; }

.bottom-action {
  position: fixed; bottom: 0; left: 0; right: 0;
  padding: 20rpx 30rpx 40rpx; background: #FFF9F5;
}
.start-btn {
  padding: 28rpx; border-radius: 16rpx; text-align: center;
  box-shadow: 0 4rpx 16rpx rgba(0,0,0,0.1);
}
.start-text { font-size: 32rpx; font-weight: 600; color: #fff; }

/* 解锁弹窗 */
.modal-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5); z-index: 200;
  display: flex; align-items: center; justify-content: center;
}
.unlock-modal {
  width: 600rpx; background: #fff; border-radius: 24rpx;
  padding: 60rpx 40rpx; text-align: center;
}
.unlock-emoji { font-size: 80rpx; display: block; margin-bottom: 20rpx; }
.unlock-name { font-size: 36rpx; font-weight: bold; color: #333; display: block; }
.unlock-style { font-size: 26rpx; color: #999; display: block; margin-top: 8rpx; }
.unlock-hint { font-size: 26rpx; color: #666; display: block; margin: 30rpx 0; }
.unlock-actions { display: flex; gap: 20rpx; }
.unlock-btn {
  flex: 1; padding: 24rpx; border-radius: 12rpx; text-align: center; font-size: 26rpx;
}
.unlock-btn.share { background: #07C160; color: #fff; }
.unlock-btn.ad { background: #FF9500; color: #fff; }
.unlock-cancel { margin-top: 24rpx; padding: 20rpx; font-size: 26rpx; color: #999; }
</style>
