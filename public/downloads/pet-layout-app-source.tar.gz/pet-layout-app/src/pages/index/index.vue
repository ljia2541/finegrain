<template>
  <view class="page">
    <!-- 侧边抽屉 -->
    <view class="drawer-overlay" v-if="drawerOpen" @tap="drawerOpen = false">
      <view class="drawer" @tap.stop>
        <view class="drawer-header">
          <text class="drawer-title">轻治愈动物笔记</text>
          <text class="drawer-version">v1.0.0</text>
        </view>
        <view class="drawer-menu">
          <view class="drawer-item" @tap="goTab('/pages/index/index')">
            <text>🏠 首页</text>
          </view>
          <view class="drawer-item" @tap="goTab('/pages/animals/index')">
            <text>🐾 选择动物</text>
          </view>
          <view class="drawer-item" @tap="goTab('/pages/notes/index')">
            <text>📚 笔记管理</text>
          </view>
          <view class="drawer-item" @tap="goTab('/pages/settings/index')">
            <text>⚙️ 设置</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 顶部 -->
    <view class="header">
      <view class="avatar-btn" @tap="drawerOpen = !drawerOpen">
        <text class="avatar-emoji">🐱</text>
      </view>
      <view class="header-text">
        <text class="greeting">{{ greeting }}</text>
      </view>
      <view class="font-btn" @tap="showFontPicker = true">
        <text class="font-icon">Aa</text>
      </view>
    </view>

    <!-- 每日语录 -->
    <view class="daily-quote">
      <text class="quote-text">{{ dailyQuote }}</text>
    </view>

    <!-- 月度打卡日历 -->
    <view class="calendar-section">
      <view class="calendar-header">
        <text class="section-title">📅 {{ currentMonth }}</text>
        <text class="calendar-count">本月 {{ monthCheckinCount }} 天</text>
      </view>
      <!-- 星期标题 -->
      <view class="weekdays">
        <text v-for="wd in weekdays" :key="wd" class="weekday-text">{{ wd }}</text>
      </view>
      <!-- 日期网格 -->
      <view class="calendar-grid">
        <!-- 前置空位 -->
        <view v-for="n in firstDayOffset" :key="'blank'+n" class="cal-cell empty" />
        <!-- 实际日期 -->
        <view
          v-for="d in daysInMonth"
          :key="'day'+d"
          class="cal-cell"
          :class="{
            checked: isChecked(d),
            today: isToday(d),
            future: isFuture(d),
          }"
        >
          <text class="cal-text">{{ d }}</text>
        </view>
      </view>
    </view>

    <!-- 收纳箱网格 -->
    <view class="storage-section">
      <text class="section-title">🐾 我的收纳箱</text>
      <view class="storage-grid">
        <view
          v-for="animal in animals"
          :key="animal.id"
          class="storage-card"
          :style="{ borderColor: animal.style.primaryColor }"
          @tap="openAnimal(animal)"
        >
          <view class="storage-icon" :style="{ background: animal.style.bgColor }">
            <text class="icon-emoji">{{ getEmoji(animal.species) }}</text>
            <view v-if="!isUnlocked(animal.id)" class="lock-overlay">
              <text>🔒</text>
            </view>
          </view>
          <text class="storage-name">{{ animal.name }}</text>
          <text class="storage-box">{{ animal.storageBox }}</text>
          <text class="storage-count">{{ getNoteCount(animal.id) }} 篇</text>
        </view>
      </view>
    </view>

    <!-- 新建笔记悬浮按钮 -->
    <view class="fab" @tap="createNote">
      <text class="fab-icon">＋</text>
    </view>

    <!-- 字体选择弹窗 -->
    <view class="modal-overlay" v-if="showFontPicker" @tap="showFontPicker = false">
      <view class="font-modal" @tap.stop>
        <text class="modal-title">选择书写字体</text>
        <text class="modal-subtitle">免费商用 · 全局生效</text>
        <view class="font-list">
          <view
            v-for="font in allFonts"
            :key="font.id"
            class="font-item"
            :class="{ active: currentFontId === font.id }"
            @tap="selectFont(font.id)"
          >
            <text class="font-name">{{ font.name }}</text>
            <text class="font-desc">{{ font.description }}</text>
          </view>
        </view>
        <view class="size-section">
          <text class="size-label">字号</text>
          <view class="size-options">
            <view v-for="size in allSizes" :key="size.id" class="size-btn"
              :class="{ active: currentSizeId === size.id }"
              @tap="setFontSize(size.id)">
              <text>{{ size.label }}</text>
            </view>
          </view>
        </view>
      </view>
    </view>

    <!-- 解锁弹窗 -->
    <view class="modal-overlay" v-if="unlockTarget" @tap="unlockTarget = null">
      <view class="unlock-modal" @tap.stop>
        <text class="unlock-emoji">{{ getEmoji(unlockTarget.species) }}</text>
        <text class="unlock-name">{{ unlockTarget.name }}</text>
        <text class="unlock-style">{{ unlockTarget.styleName }}</text>
        <text class="unlock-hint">选择一种方式解锁</text>
        <view class="unlock-actions">
          <view class="unlock-btn share" @tap="unlockByShare">
            <text>📤 分享给好友解锁</text>
          </view>
          <view class="unlock-btn ad" @tap="unlockByAd">
            <text>🎬 观看广告解锁</text>
          </view>
        </view>
        <view class="unlock-cancel" @tap="unlockTarget = null">
          <text>稍后再说</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { animals, getAnimalEmoji, type AnimalConfig } from '../../templates/animals'
import { fonts, fontSizes } from '../../templates/fonts'
import {
  isAnimalUnlocked, unlockAnimal,
  getNotes, getDailyQuote, getFontSettings, saveFontSettings,
  getMonthCheckinDays,
  type FontSettings,
} from '../../utils/storage'
import { getCurrentAnimalId, setCurrentAnimalId } from '../../utils/animalState'

const drawerOpen = ref(false)
const showFontPicker = ref(false)
const unlockTarget = ref<AnimalConfig | null>(null)
const allFonts = fonts
const allSizes = fontSizes
const dailyQuote = getDailyQuote()

// 字体状态
const fontSettings = ref<FontSettings>(getFontSettings())
const currentFontId = ref(fontSettings.value.fontId)
const currentSizeId = ref(fontSettings.value.fontSizeId)

// === 打卡日历 ===
const now = new Date()
const curYear = now.getFullYear()
const curMonth = now.getMonth() + 1
const curDate = now.getDate()

const weekdays = ['一', '二', '三', '四', '五', '六', '日']

const currentMonth = computed(() => `${curYear}年${curMonth}月`)

// 本月天数
const daysInMonth = computed(() => {
  return new Date(curYear, curMonth, 0).getDate()
})

// 本月1号是周几（周一=0, 周日=6）
const firstDayOffset = computed(() => {
  const day = new Date(curYear, curMonth - 1, 1).getDay()
  return day === 0 ? 6 : day - 1  // 转为周一起始
})

// 本月打卡天
const checkedDays = ref(getMonthCheckinDays(curYear, curMonth))

// 页面显示时刷新打卡数据
onMounted(() => {
  checkedDays.value = getMonthCheckinDays(curYear, curMonth)
})

const monthCheckinCount = computed(() => checkedDays.value.length)

function isChecked(d: number) {
  return checkedDays.value.includes(d)
}

function isToday(d: number) {
  return d === curDate
}

function isFuture(d: number) {
  return d > curDate
}

// === 问候语 ===
const greeting = computed(() => {
  const h = now.getHours()
  if (h < 6) return '夜深了 🌙'
  if (h < 9) return '早上好 ☀️'
  if (h < 12) return '上午好 🌿'
  if (h < 14) return '中午好 🍃'
  if (h < 18) return '下午好 🌸'
  if (h < 22) return '晚上好 🌙'
  return '夜深了 🌙'
})

// === 通用方法 ===
function getEmoji(species: string) { return getAnimalEmoji(species) }
function isUnlocked(id: string) { return isAnimalUnlocked(id) }
function getNoteCount(animalId: string) { return getNotes().filter(n => n.animalId === animalId && !n.hidden).length }

function openAnimal(animal: AnimalConfig) {
  if (!isAnimalUnlocked(animal.id)) {
    unlockTarget.value = animal
    return
  }
  setCurrentAnimalId(animal.id)
  uni.navigateTo({ url: `/pages/notes/index?animalId=${animal.id}` })
}

function createNote() {
  const animalId = getCurrentAnimalId()
  uni.navigateTo({ url: `/pages/editor/index?animalId=${animalId}` })
}

function selectFont(fontId: string) {
  currentFontId.value = fontId
  fontSettings.value.fontId = fontId
  saveFontSettings(fontSettings.value)
}

function setFontSize(sizeId: string) {
  currentSizeId.value = sizeId
  fontSettings.value.fontSizeId = sizeId
  saveFontSettings(fontSettings.value)
}

function goTab(url: string) {
  drawerOpen.value = false
  uni.switchTab({ url })
}

// === 解锁 ===
async function unlockByShare() {
  if (!unlockTarget.value) return
  try {
    await uni.shareAppMessage({
      title: `轻治愈动物笔记 - 用${unlockTarget.value.name}记录生活`,
      path: '/pages/index/index',
    })
    unlockAnimal(unlockTarget.value.id)
    unlockTarget.value = null
    uni.showToast({ title: '解锁成功！', icon: 'success' })
  } catch {
    // 用户取消分享
  }
}

function unlockByAd() {
  if (!unlockTarget.value) return
  // TODO: 接入微信流量主激励视频广告
  // 预留接口：uni.createRewardedVideoAd({...}).show()
  // 广告观看完成后调用 unlockAnimal(unlockTarget.value.id)
  uni.showToast({ title: '广告功能即将上线', icon: 'none' })
}
</script>

<style scoped>
.page {
  min-height: 100vh;
  background: #FFF9F5;
  padding-bottom: 140rpx;
}

/* 侧边抽屉 */
.drawer-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.3); z-index: 100;
}
.drawer {
  width: 560rpx; height: 100vh; background: #fff;
  padding: 80rpx 40rpx; box-shadow: 4rpx 0 20rpx rgba(0,0,0,0.1);
}
.drawer-header { margin-bottom: 60rpx; }
.drawer-title { font-size: 36rpx; font-weight: bold; color: #333; display: block; }
.drawer-version { font-size: 24rpx; color: #999; margin-top: 8rpx; display: block; }
.drawer-item {
  padding: 30rpx 0; font-size: 32rpx; color: #555;
  border-bottom: 1rpx solid #f0f0f0;
}

/* 顶部 */
.header {
  display: flex; align-items: center; padding: 30rpx 30rpx 20rpx;
}
.avatar-btn {
  width: 72rpx; height: 72rpx; border-radius: 50%; background: #F5EDE3;
  display: flex; align-items: center; justify-content: center;
}
.avatar-emoji { font-size: 36rpx; }
.header-text { flex: 1; margin-left: 20rpx; }
.greeting { font-size: 32rpx; font-weight: 600; color: #333; }
.font-btn {
  width: 64rpx; height: 64rpx; border-radius: 12rpx; background: #F5EDE3;
  display: flex; align-items: center; justify-content: center;
}
.font-icon { font-size: 26rpx; color: #8B7355; font-weight: 600; }

/* 每日语录 */
.daily-quote {
  margin: 20rpx 30rpx; padding: 24rpx 30rpx;
  background: linear-gradient(135deg, #FFF5E8, #F5EDE3);
  border-radius: 16rpx;
}
.quote-text { font-size: 28rpx; color: #8B7355; line-height: 1.6; }

/* 打卡日历 */
.calendar-section {
  margin: 20rpx 30rpx; background: #fff; border-radius: 16rpx;
  padding: 24rpx;
}
.calendar-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 20rpx;
}
.section-title { font-size: 30rpx; font-weight: 600; color: #333; }
.calendar-count { font-size: 24rpx; color: #C9A88A; font-weight: 500; }

.weekdays {
  display: flex; margin-bottom: 12rpx;
}
.weekday-text {
  flex: 1; text-align: center; font-size: 22rpx; color: #bbb;
}

.calendar-grid {
  display: flex; flex-wrap: wrap;
}
.cal-cell {
  width: calc(100% / 7); height: 64rpx;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 8rpx;
}
.cal-cell.empty { visibility: hidden; }
.cal-text { font-size: 24rpx; color: #999; }

.cal-cell.today .cal-text {
  color: #C9A88A; font-weight: bold;
}
.cal-cell.checked {
  position: relative;
}
.cal-cell.checked .cal-text {
  color: #fff;
}
.cal-cell.checked::after {
  content: '';
  position: absolute;
  width: 48rpx; height: 48rpx; border-radius: 50%;
  background: #C9A88A; z-index: -1;
}
.cal-cell.today.checked::after {
  background: #B8956A;
}
.cal-cell.future .cal-text {
  color: #ddd;
}

/* 收纳箱网格 */
.storage-section { margin: 30rpx 30rpx 0; }
.storage-grid { display: flex; flex-wrap: wrap; gap: 20rpx; }
.storage-card {
  width: calc(50% - 10rpx); background: #fff; border-radius: 16rpx;
  padding: 24rpx; border: 2rpx solid #e8e8e8; position: relative;
}
.storage-icon {
  width: 80rpx; height: 80rpx; border-radius: 50%;
  display: flex; align-items: center; justify-content: center; margin-bottom: 12rpx;
  position: relative;
}
.icon-emoji { font-size: 40rpx; }
.lock-overlay {
  position: absolute; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(255,255,255,0.7); border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.storage-name { font-size: 28rpx; font-weight: 600; color: #333; display: block; }
.storage-box { font-size: 22rpx; color: #999; display: block; margin-top: 4rpx; }
.storage-count { font-size: 22rpx; color: #C9A88A; display: block; margin-top: 8rpx; }

/* 悬浮按钮 */
.fab {
  position: fixed; bottom: 160rpx; right: 40rpx;
  width: 100rpx; height: 100rpx; border-radius: 50%;
  background: linear-gradient(135deg, #C9A88A, #B8956A);
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 8rpx 24rpx rgba(201,168,138,0.4); z-index: 50;
}
.fab-icon { font-size: 48rpx; color: #fff; }

/* 弹窗通用 */
.modal-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5); z-index: 200;
  display: flex; align-items: flex-end; justify-content: center;
}

/* 字体弹窗 */
.font-modal {
  width: 100%; background: #fff; border-radius: 32rpx 32rpx 0 0;
  padding: 40rpx 30rpx 60rpx; max-height: 70vh;
}
.modal-title { font-size: 34rpx; font-weight: bold; color: #333; display: block; text-align: center; }
.modal-subtitle { font-size: 24rpx; color: #999; display: block; text-align: center; margin-top: 8rpx; margin-bottom: 30rpx; }
.font-list { max-height: 40vh; overflow-y: auto; }
.font-item {
  padding: 24rpx 20rpx; border-radius: 12rpx; margin-bottom: 12rpx;
  background: #f8f8f8;
}
.font-item.active { background: #FFF5E8; border: 2rpx solid #C9A88A; }
.font-name { font-size: 30rpx; font-weight: 600; color: #333; display: block; }
.font-desc { font-size: 24rpx; color: #999; display: block; margin-top: 4rpx; }
.size-section {
  margin-top: 24rpx; display: flex; align-items: center; justify-content: space-between;
  padding-top: 24rpx; border-top: 1rpx solid #f0f0f0;
}
.size-label { font-size: 28rpx; color: #333; font-weight: 600; }
.size-options { display: flex; gap: 16rpx; }
.size-btn { padding: 12rpx 32rpx; border-radius: 8rpx; background: #f5f5f5; font-size: 26rpx; color: #666; }
.size-btn.active { background: #C9A88A; color: #fff; }

/* 解锁弹窗 */
.unlock-modal {
  width: 600rpx; background: #fff; border-radius: 24rpx;
  padding: 60rpx 40rpx; text-align: center;
  position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
}
.unlock-emoji { font-size: 80rpx; display: block; margin-bottom: 20rpx; }
.unlock-name { font-size: 36rpx; font-weight: bold; color: #333; display: block; }
.unlock-style { font-size: 26rpx; color: #999; display: block; margin-top: 8rpx; }
.unlock-hint { font-size: 26rpx; color: #666; display: block; margin: 30rpx 0; }
.unlock-actions { display: flex; gap: 20rpx; }
.unlock-btn {
  flex: 1; padding: 24rpx; border-radius: 12rpx; text-align: center; font-size: 26rpx;
}
.unlock-btn.share { background: #07C160; color: #fff; }
.unlock-btn.ad { background: #FF9500; color: #fff; }
.unlock-cancel {
  margin-top: 24rpx; padding: 20rpx; font-size: 26rpx; color: #999;
}
</style>
