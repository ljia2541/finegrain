/**
 * 轻治愈动物笔记 - 七大原创IP配置
 * 从10个动物精简为7个，全新角色设定
 */

export interface AnimalStyle {
  primaryColor: string
  secondaryColor: string
  bgColor: string
  fontColor: string
  accentColor: string
}

export interface AnimalLayout {
  padding: number
  lineHeight: number
  textAlign: 'left' | 'center' | 'right'
  titleSize: number
  bodySize: number
  borderRadius: number
}

export interface AnimalTemplate {
  id: string
  name: string
  description: string
}

export interface AnimalConfig {
  id: string
  name: string
  species: string
  styleName: string        // 风格定位
  storageBox: string       // 专属收纳箱名称
  loadingText: string      // 加载文案
  style: AnimalStyle
  layout: AnimalLayout
  templates: AnimalTemplate[]
  recommendedFont: string  // 推荐字体
  unlockType: 'free' | 'share' | 'ad'
}

export const animals: AnimalConfig[] = [
  {
    id: 'anan',
    name: '安安',
    species: '布偶猫',
    styleName: '日系简约 / 素雅信纸',
    storageBox: '安安的读书箱',
    loadingText: '安安正在整理信纸，打造干净简约笔记…',
    style: {
      primaryColor: '#E8D5C4',
      secondaryColor: '#F5EDE3',
      bgColor: '#FFF9F5',
      fontColor: '#5C4A3A',
      accentColor: '#C9A88A',
    },
    layout: {
      padding: 48,
      lineHeight: 2.0,
      textAlign: 'left',
      titleSize: 20,
      bodySize: 15,
      borderRadius: 16,
    },
    templates: [
      { id: 'anan_wood', name: '原木留白', description: '温暖木质纹理，大量留白' },
      { id: 'anan_grid', name: '浅纹格纸', description: '淡雅网格，日系文具感' },
      { id: 'anan_morandi', name: '莫兰迪纯色', description: '低饱和纯色，安静柔和' },
    ],
    recommendedFont: 'serif_jp',
    unlockType: 'free',
  },
  {
    id: 'tietie',
    name: '贴贴',
    species: '垂耳兔',
    styleName: '森系手作 / 绿植胶带',
    storageBox: '贴贴的手作箱',
    loadingText: '贴贴正在裁剪贴纸，搭配温柔手账版式…',
    style: {
      primaryColor: '#7BA37E',
      secondaryColor: '#E5F0E6',
      bgColor: '#F2F8F2',
      fontColor: '#3A5C3C',
      accentColor: '#A8C8A0',
    },
    layout: {
      padding: 44,
      lineHeight: 2.0,
      textAlign: 'center',
      titleSize: 18,
      bodySize: 15,
      borderRadius: 20,
    },
    templates: [
      { id: 'tietie_tape', name: '胶带边框', description: '手作胶带装饰，手账风' },
      { id: 'tietie_botanical', name: '干植肌理', description: '干花植物纹理，自然质感' },
      { id: 'tietie_torn', name: '撕边手作', description: '撕纸边缘，质朴手工感' },
    ],
    recommendedFont: 'round_cream',
    unlockType: 'free',
  },
  {
    id: 'banban',
    name: '办办',
    species: '柴犬',
    styleName: '轻商务 / 日常清单',
    storageBox: '办办的办公箱',
    loadingText: '办办正在整理日程，打造清晰利落记录…',
    style: {
      primaryColor: '#B8956A',
      secondaryColor: '#F5EDE3',
      bgColor: '#FDF8F0',
      fontColor: '#4A3A2A',
      accentColor: '#8B7355',
    },
    layout: {
      padding: 40,
      lineHeight: 1.8,
      textAlign: 'left',
      titleSize: 22,
      bodySize: 14,
      borderRadius: 4,
    },
    templates: [
      { id: 'banban_lines', name: '横线记事', description: '经典横线纸，整洁办公风' },
      { id: 'banban_coffee', name: '暖咖纸张', description: '咖啡色纸张，温暖商务' },
      { id: 'banban_todo', name: '日程清单', description: '待办清单模板，高效规划' },
    ],
    recommendedFont: 'biz_hei',
    unlockType: 'free',
  },
  {
    id: 'momo',
    name: '墨墨',
    species: '熊猫',
    styleName: '古风书法 / 宣纸国风',
    storageBox: '墨墨的宣纸箱',
    loadingText: '墨墨正在提笔书写，沉淀中式雅致质感…',
    style: {
      primaryColor: '#6B4226',
      secondaryColor: '#E8D5B7',
      bgColor: '#F5EDE0',
      fontColor: '#3D2B1F',
      accentColor: '#8B0000',
    },
    layout: {
      padding: 48,
      lineHeight: 2.2,
      textAlign: 'center',
      titleSize: 20,
      bodySize: 16,
      borderRadius: 0,
    },
    templates: [
      { id: 'momo_xuan', name: '素色宣纸', description: '纯净宣纸质感，文房四宝' },
      { id: 'momo_seal', name: '朱砂印章', description: '古典印章装饰，国风韵味' },
      { id: 'momo_scroll', name: '古典卷轴', description: '卷轴边框，古朴雅致' },
    ],
    recommendedFont: 'warm_kai',
    unlockType: 'share',
  },
  {
    id: 'youyou',
    name: '邮邮',
    species: '小狐狸',
    styleName: '旅行明信片 / 复古拼贴',
    storageBox: '邮邮的旅行箱',
    loadingText: '邮邮收集沿途风景，定格每一段旅程…',
    style: {
      primaryColor: '#C4A35A',
      secondaryColor: '#F5E6C8',
      bgColor: '#FDF8EE',
      fontColor: '#5C4B2E',
      accentColor: '#8B7355',
    },
    layout: {
      padding: 44,
      lineHeight: 1.9,
      textAlign: 'left',
      titleSize: 18,
      bodySize: 14,
      borderRadius: 8,
    },
    templates: [
      { id: 'youyou_polaroid', name: '拍立得白边', description: '拍立得相纸效果，旅行记忆' },
      { id: 'youyou_postmark', name: '复古邮戳', description: '邮戳装饰，明信片风格' },
      { id: 'youyou_ticket', name: '车票拼贴', description: '车票、地图拼贴，旅途感' },
    ],
    recommendedFont: 'art_handwrite',
    unlockType: 'share',
  },
  {
    id: 'diandian',
    name: '点点',
    species: '小企鹅',
    styleName: '像素复古 / 极简数码',
    storageBox: '点点的像素箱',
    loadingText: '点点搭建像素画布，打造小众文艺风格…',
    style: {
      primaryColor: '#4A5568',
      secondaryColor: '#E2E8F0',
      bgColor: '#F7FAFC',
      fontColor: '#2D3748',
      accentColor: '#63B3ED',
    },
    layout: {
      padding: 40,
      lineHeight: 1.8,
      textAlign: 'left',
      titleSize: 16,
      bodySize: 13,
      borderRadius: 0,
    },
    templates: [
      { id: 'diandian_window', name: '复古窗口', description: '像素窗口边框，怀旧数码' },
      { id: 'diandian_dark', name: '深色极简', description: '深色背景，荧光字体' },
      { id: 'diandian_pixel', name: '像素备忘录', description: '像素风备忘录，复古游戏感' },
    ],
    recommendedFont: 'thin_hei',
    unlockType: 'share',
  },
  {
    id: 'chacha',
    name: '查查',
    species: '小狮子',
    styleName: '纯白极简 / 冷淡高级',
    storageBox: '查查的审核箱',
    loadingText: '查查精简排版，保持干净清爽记录…',
    style: {
      primaryColor: '#A0AEC0',
      secondaryColor: '#EDF2F7',
      bgColor: '#FFFFFF',
      fontColor: '#1A202C',
      accentColor: '#CBD5E0',
    },
    layout: {
      padding: 44,
      lineHeight: 2.0,
      textAlign: 'center',
      titleSize: 18,
      bodySize: 14,
      borderRadius: 2,
    },
    templates: [
      { id: 'chacha_white', name: '纯白底色', description: '极致纯白，零装饰高级感' },
      { id: 'chacha_lines', name: '细线条公文', description: '纤细线条，冷淡公文风' },
      { id: 'chacha_gray', name: '浅灰低饱和', description: '浅灰背景，低饱和冷静' },
    ],
    recommendedFont: 'thin_hei',
    unlockType: 'share',
  },
]

export function getAnimal(id: string): AnimalConfig | undefined {
  return animals.find((a) => a.id === id)
}

export function getDefaultAnimals(): AnimalConfig[] {
  return animals.filter((a) => a.unlockType === 'free')
}

export function getLockedAnimals(): AnimalConfig[] {
  return animals.filter((a) => a.unlockType !== 'free')
}

/** 获取动物 emoji */
export function getAnimalEmoji(species: string): string {
  const map: Record<string, string> = {
    '布偶猫': '🐱',
    '垂耳兔': '🐰',
    '柴犬': '🐕',
    '熊猫': '🐼',
    '小狐狸': '🦊',
    '小企鹅': '🐧',
    '小狮子': '🦁',
  }
  return map[species] || '🐾'
}
