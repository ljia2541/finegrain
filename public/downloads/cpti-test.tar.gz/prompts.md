# CPTI 关系测试 - 25 张插图 Prompt

## 统一风格前缀（每条 prompt 前都加）
Flat vector illustration, two cute minimalist characters, chibi style, warm pastel colors, clean white background, simple shapes, no text, no watermark, WeChat mini-program sticker style --ar 1:1 --v 6

---

## 1. 灵魂同频
...two characters sitting back to back with glowing aura connecting them, eyes closed, peaceful expression, purple-blue gradient energy between them

## 2. 镜像知己
...two identical characters mirroring each other's pose, one in blue one in pink, connected by a mirror reflection effect

## 3. 默契同盟
...two characters doing a fist bump, both smiling confidently, sparkles around their hands

## 4. 互怼搭档
...two characters pointing at each other with angry faces but small hearts floating between them, comedic style

## 5. 引路同行
...one taller character walking ahead on a path, holding hand and guiding a smaller character, mountains in soft background

## 6. 守护与被守护
...one character holding an umbrella over the other who is sitting peacefully, rain drops around but they are dry and warm

## 7. 依靠与被依靠
...two characters leaning on each other shoulder to shoulder, cozy and relaxed, small house silhouette in background

## 8. 稳定后盾
...one character standing firmly like a wall behind the other who is moving forward, shield shape glowing behind

## 9. 一路搭子
...two characters walking side by side with backpacks, happy-go-lucky vibe, small footprints trail behind them

## 10. 同频玩伴
...two characters playing a game together, both holding controllers, big joyful smiles, confetti around

## 11. 目标战友
...two characters standing side by side pointing forward at the same direction, determined expressions, arrow shape ahead

## 12. 快乐搭子
...two characters jumping together with arms raised, confetti and balloons around, pure joy

## 13. 小众同好
...two characters sharing headphones together, sitting on floor, both eyes closed enjoying music, vinyl record nearby

## 14. 互补拍档
...one character energetic and jumping, the other calm and reading, connected by a yin-yang symbol between them

## 15. 温和包容组
...two characters sitting in a warm hug, soft clouds and flowers around, very gentle and tender mood

## 16. 气氛双人组
...two characters being the life of the party, one holding microphone the other dancing, musical notes and stars around

## 17. 长久陪伴型
...two characters on a bench under a tree, one leaning on the other, autumn leaves falling gently

## 18. 轻松相处型
...two characters lying on grass looking up, both relaxed and carefree, clouds shaped like smiley faces above

## 19. 彼此支撑型
...two characters high-fiving with determination, one has a bandaid and the other gives thumbs up

## 20. 深度理解者
...one character looking through a telescope at the other who is behind a mask, revealing true self

## 21. 三观高度契合
...two characters looking at the same starry sky, thought bubbles showing identical shapes, night scene

## 22. 温柔治愈组
...one character wrapping a blanket around the other who is crying softly, warm light glow, flowers blooming

## 23. 习惯相似组
...two characters sitting at a cafe table with identical poses and drinks, mirror composition

## 24. 特别缘分
...two characters connected by a red thread of fate, meeting at a crossroads, soft golden light

## 25. 理想契合型
...two characters building a house of blocks together, harmonious and focused, rainbow in background

---

## 生成建议

1. **工具推荐**：Midjourney v6 或 DALL-E 3
2. **尺寸**：1:1 正方形（1024x1024）
3. **格式**：PNG（去背景后使用）
4. **去背景**：用 remove.bg 批量去除白底
5. **命名**：relation_01.png ~ relation_25.png
6. **存放位置**：小程序 /images/relations/ 目录

## 如果用 Midjourney，完整 prompt 示例：

Flat vector illustration, two cute minimalist characters, chibi style, warm pastel colors, clean white background, simple shapes, no text, no watermark, WeChat mini-program sticker style, two characters sitting back to back with glowing aura connecting them, eyes closed, peaceful expression, purple-blue gradient energy between them --ar 1:1 --v 6

## 如果用 DALL-E 3，直接用描述部分即可（去掉 --ar 等参数）
