const questions = require('../../data/questions')
const { calcScore, normalize, getMainType, genId } = require('../../utils/cpti')

Page({
  data: {
    current: 0,
    total: 0,
    question: {},
    progress: 0,
    answers: [],
  },

  score: { C: 0, G: 0, L: 0, S: 0, T: 0 },

  onLoad() {
    this.setData({
      total: questions.length,
      question: questions[0],
      progress: (1 / questions.length) * 100,
    })
  },

  answer(e) {
    const val = e.currentTarget.dataset.val
    const currentQuestion = questions[this.data.current]

    // 累计分数
    calcScore(currentQuestion, val, this.score)

    const answers = this.data.answers.concat({
      id: currentQuestion.id,
      answer: val,
    })

    const next = this.data.current + 1

    if (next >= questions.length) {
      // 完成所有题目，计算结果
      const normalized = normalize(this.score)
      const mainType = getMainType(normalized)
      const cpId = genId()

      // 保存到云数据库
      this.saveResult(normalized, mainType, cpId, answers)

      wx.redirectTo({
        url: `/pages/result/result?C=${normalized.C}&G=${normalized.G}&L=${normalized.L}&S=${normalized.S}&T=${normalized.T}&type=${mainType}&cpId=${cpId}`,
      })
    } else {
      this.setData({
        current: next,
        question: questions[next],
        progress: ((next + 1) / questions.length) * 100,
        answers,
      })
    }
  },

  saveResult(normalized, mainType, cpId, answers) {
    const db = wx.cloud.database()
    db.collection('results').add({
      data: {
        score: normalized,
        mainType,
        cpId,
        answerCount: answers.length,
        createTime: db.serverDate(),
      },
    }).catch(err => {
      console.error('保存失败', err)
    })
  },
})
