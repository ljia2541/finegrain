<template>
  <view class="page">
    <!-- 动物筛选 Tab -->
    <scroll-view scroll-x class="filter-tabs">
      <view
        class="tab"
        :class="{ active: filterAnimal === 'all' }"
        @tap="filterAnimal = 'all'"
      >
        <text>全部</text>
      </view>
      <view
        v-for="animal in unlockedAnimals"
        :key="animal.id"
        class="tab"
        :class="{ active: filterAnimal === animal.id }"
        @tap="filterAnimal = animal.id"
      >
        <text>{{ getAnimalEmojiStr(animal.species) }} {{ animal.name }}</text>
      </view>
    </scroll-view>

    <!-- 笔记列表 -->
    <view class="notes-list">
      <view v-if="filteredNotes.length === 0" class="empty-state">
        <text class="empty-icon">📝</text>
        <text class="empty-text">还没有笔记，去写一篇吧</text>
        <view class="empty-btn" @tap="createNote">
          <text>开始写笔记</text>
        </view>
      </view>

      <view
        v-for="note in filteredNotes"
        :key="note.id"
        class="note-card"
        @tap="editNote(note)"
        @longpress="showActions(note)"
      >
        <view class="note-header">
          <view class="note-animal-badge" :style="{ background: getAnimalStyle(note.animalId)?.bgColor }">
            <text class="badge-emoji">{{ getAnimalEmojiStr(note.animalId) }}</text>
          </view>
          <view class="note-meta">
            <text class="note-animal-name">{{ getAnimalName(note.animalId) }}</text>
            <text class="note-date">{{ formatDate(note.createdAt) }}</text>
          </view>
          <view class="note-actions-inline">
            <text v-if="note.starred" class="star-active" @tap.stop="toggleStarNote(note.id)">⭐</text>
            <text v-else class="star-inactive" @tap.stop="toggleStarNote(note.id)">☆</text>
          </view>
        </view>
        <!-- 图片预览 -->
        <view v-if="note.imagePaths && note.imagePaths.length > 0" class="note-images">
          <image v-for="(img, idx) in note.imagePaths.slice(0, 3)" :key="idx"
            :src="img" mode="aspectFill" class="note-thumb" />
        </view>
        <text class="note-content">{{ note.content.slice(0, 100) }}{{ note.content.length > 100 ? '...' : '' }}</text>
        <text class="note-template">{{ getTemplateName(note.animalId, note.templateId) }}</text>
      </view>
    </view>

    <!-- 长按操作菜单 -->
    <view class="modal-overlay" v-if="actionNote" @tap="actionNote = null">
      <view class="action-sheet" @tap.stop>
        <view class="sheet-item" @tap="editNote(actionNote!)">
          <text>✏️ 编辑</text>
        </view>
        <view class="sheet-item" @tap="toggleHideNote(actionNote!.id)">
          <text>{{ actionNote!.hidden ? '👁 取消隐藏' : '🙈 隐藏' }}</text>
        </view>
        <view class="sheet-item danger" @tap="confirmDelete(actionNote!.id)">
          <text>🗑 删除</text>
        </view>
        <view class="sheet-cancel" @tap="actionNote = null">
          <text>取消</text>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { animals, getAnimalEmoji, getAnimal } from '../../templates/animals'
import { getNotes, toggleStar, toggleHidden, deleteNote, isAnimalUnlocked, type NoteRecord } from '../../utils/storage'
import { getCurrentAnimalId } from '../../utils/animalState'

const filterAnimal = ref('all')
const actionNote = ref<NoteRecord | null>(null)
const refreshKey = ref(0) // 强制刷新标记

onMounted(() => {
  // 从首页收纳箱跳转时带 animalId
  try {
    const pages = getCurrentPages()
    const currentPage = pages[pages.length - 1] as any
    const query = currentPage?.options || currentPage?.$page?.options || {}
    if (query.animalId) {
      filterAnimal.value = query.animalId
    }
  } catch {}
})

const unlockedAnimals = computed(() => animals.filter(a => isAnimalUnlocked(a.id)))

const filteredNotes = computed(() => {
  refreshKey.value // 依赖刷新标记
  let notes = getNotes()
  if (filterAnimal.value !== 'all') {
    notes = notes.filter(n => n.animalId === filterAnimal.value)
  }
  return notes.filter(n => !n.hidden).sort((a, b) => b.updatedAt - a.updatedAt)
})

function getAnimalEmojiStr(idOrSpecies: string) {
  const animal = getAnimal(idOrSpecies)
  if (animal) return getAnimalEmoji(animal.species)
  return getAnimalEmoji(idOrSpecies)
}

function getAnimalStyle(animalId: string) { return getAnimal(animalId)?.style }
function getAnimalName(animalId: string) { return getAnimal(animalId)?.name || '未知' }

function getTemplateName(animalId: string, templateId: string) {
  const animal = getAnimal(animalId)
  const tpl = animal?.templates.find(t => t.id === templateId)
  return tpl?.name || ''
}

function formatDate(ts: number) {
  const d = new Date(ts)
  return `${d.getMonth()+1}/${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`
}

function editNote(note: NoteRecord) {
  uni.navigateTo({ url: `/pages/editor/index?noteId=${note.id}` })
}

function createNote() {
  const animalId = filterAnimal.value !== 'all' ? filterAnimal.value : getCurrentAnimalId()
  uni.navigateTo({ url: `/pages/editor/index?animalId=${animalId}` })
}

function showActions(note: NoteRecord) {
  actionNote.value = note
}

function toggleStarNote(id: string) {
  toggleStar(id)
  refreshKey.value++
}

function toggleHideNote(id: string) {
  toggleHidden(id)
  refreshKey.value++
  actionNote.value = null
}

function confirmDelete(id: string) {
  uni.showModal({
    title: '确认删除',
    content: '删除后无法恢复，确定要删除吗？',
    success: (res) => {
      if (res.confirm) {
        deleteNote(id)
        refreshKey.value++
        actionNote.value = null
      }
    },
  })
}
</script>

<style scoped>
.page { min-height: 100vh; background: #FFF9F5; }

.filter-tabs {
  white-space: nowrap; padding: 20rpx 30rpx;
  background: #fff; border-bottom: 1rpx solid #f0f0f0;
}
.tab {
  display: inline-flex; padding: 16rpx 28rpx; border-radius: 32rpx;
  margin-right: 16rpx; font-size: 26rpx; color: #666; background: #f5f5f5;
}
.tab.active { background: #C9A88A; color: #fff; }

.notes-list { padding: 20rpx 30rpx; }
.empty-state { text-align: center; padding: 120rpx 0; }
.empty-icon { font-size: 80rpx; display: block; margin-bottom: 20rpx; }
.empty-text { font-size: 28rpx; color: #999; display: block; margin-bottom: 30rpx; }
.empty-btn {
  display: inline-flex; padding: 20rpx 48rpx; border-radius: 32rpx;
  background: linear-gradient(135deg, #C9A88A, #B8956A); color: #fff;
  font-size: 28rpx;
}

.note-card {
  background: #fff; border-radius: 16rpx; padding: 24rpx;
  margin-bottom: 20rpx; box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.04);
}
.note-header { display: flex; align-items: center; gap: 16rpx; margin-bottom: 12rpx; }
.note-animal-badge {
  width: 56rpx; height: 56rpx; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.badge-emoji { font-size: 28rpx; }
.note-meta { flex: 1; }
.note-animal-name { font-size: 26rpx; font-weight: 600; color: #333; display: block; }
.note-date { font-size: 22rpx; color: #999; display: block; }
.star-active { font-size: 32rpx; }
.star-inactive { font-size: 32rpx; color: #ddd; }

.note-images {
  display: flex; gap: 8rpx; margin-bottom: 12rpx;
}
.note-thumb { width: 120rpx; height: 120rpx; border-radius: 8rpx; }

.note-content { font-size: 28rpx; color: #555; line-height: 1.6; display: block; }
.note-template { font-size: 22rpx; color: #C9A88A; display: block; margin-top: 8rpx; }

/* 操作菜单 */
.modal-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.4); z-index: 200;
  display: flex; align-items: flex-end;
}
.action-sheet {
  width: 100%; background: #fff; border-radius: 32rpx 32rpx 0 0;
  padding: 20rpx 30rpx 60rpx;
}
.sheet-item {
  padding: 30rpx; font-size: 30rpx; color: #333;
  border-bottom: 1rpx solid #f0f0f0; text-align: center;
}
.sheet-item.danger { color: #E53E3E; }
.sheet-cancel { padding: 30rpx; font-size: 30rpx; color: #999; text-align: center; }
</style>
