"use strict";const e={};const r=require("../../common/vendor.js")._export_sfc(e,[["render",function(e,r){return{}}],["__scopeId","data-v-caf62314"]]);wx.createPage(r);
