/**
 * 全局状态：当前选中的动物
 * 小程序下用 uni.setStorageSync 持久化
 */

const CURRENT_ANIMAL_KEY = 'qzy_current_animal'

/** 获取当前选中的动物ID */
export function getCurrentAnimalId(): string {
  try {
    return uni.getStorageSync(CURRENT_ANIMAL_KEY) || 'anan'
  } catch {
    return 'anan'
  }
}

/** 设置当前选中的动物ID */
export function setCurrentAnimalId(id: string): void {
  try {
    uni.setStorageSync(CURRENT_ANIMAL_KEY, id)
  } catch {}
}
