/**
 * Canvas 导出工具
 * 使用 uni-app Canvas 2D API 将笔记渲染为图片并保存到相册
 */

import { drawTemplate, type DrawOptions } from '../templates/renderer'
import { getAnimal } from '../templates/animals'
import { getFontSettings, type NoteRecord } from './storage'

/** 导出图片到相册 */
export async function exportNoteAsImage(note: NoteRecord): Promise<string> {
  const animal = getAnimal(note.animalId)
  if (!animal) throw new Error('动物不存在')

  const fontSettings = getFontSettings()
  const fontSize = note.fontSizeId === 'small' ? 14 : note.fontSizeId === 'large' ? 18 : 16

  // Canvas 尺寸（正方形 3:4）
  const canvasWidth = 750
  const canvasHeight = 1000

  return new Promise((resolve, reject) => {
    // 动态创建 canvas（uni-app 小程序方式）
    const query = uni.createSelectorQuery()
    query.select('#exportCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res || !res[0]) {
          reject(new Error('Canvas 节点未找到'))
          return
        }

        const canvas = res[0].node
        const ctx = canvas.getContext('2d')

        // 设置 Canvas 实际像素
        const dpr = uni.getWindowInfo().pixelRatio || 2
        canvas.width = canvasWidth * dpr
        canvas.height = canvasHeight * dpr
        ctx.scale(dpr, dpr)

        // 绘制模板
        const options: DrawOptions = {
          canvas,
          width: canvasWidth,
          height: canvasHeight,
          content: note.content,
          imagePaths: note.imagePaths,
          animalId: note.animalId,
          templateId: note.templateId,
          fontId: note.fontId || fontSettings.fontId,
          fontSize,
        }

        drawTemplate(options)

        // 导出图片
        uni.canvasToTempFilePath({
          canvas,
          width: canvasWidth,
          height: canvasHeight,
          destWidth: canvasWidth * 2,
          destHeight: canvasHeight * 2,
          fileType: 'png',
          quality: 1,
          success: (tempRes) => {
            // 保存到相册
            uni.saveImageToPhotosAlbum({
              filePath: tempRes.tempFilePath,
              success: () => {
                resolve(tempRes.tempFilePath)
              },
              fail: (err) => {
                // 可能没有相册权限
                if (err.errMsg?.includes('auth deny')) {
                  uni.showModal({
                    title: '需要相册权限',
                    content: '请在设置中允许访问相册',
                    confirmText: '去设置',
                    success: (modalRes) => {
                      if (modalRes.confirm) {
                        uni.openSetting({})
                      }
                    },
                  })
                }
                reject(err)
              },
            })
          },
          fail: (err) => {
            reject(err)
          },
        })
      })
  })
}

/** 无水印导出（预留广告接口） */
export async function exportNoteAsImageNoWatermark(note: NoteRecord): Promise<string> {
  // TODO: 接入微信流量主激励视频广告
  // 广告看完后执行无水印导出
  // uni.createRewardedVideoAd({...}).show().then(() => { ... })
  throw new Error('广告功能即将上线')
}
