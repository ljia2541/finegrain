<template>
  <view class="page">
    <!-- 顶部工具栏 -->
    <view class="toolbar">
      <view class="tool-btn" @tap="goBack">
        <text>← 返回</text>
      </view>
      <view class="toolbar-center" @tap="showAnimalPicker = true">
        <view class="toolbar-animal-row">
          <text class="toolbar-emoji">{{ currentAnimalEmoji }}</text>
          <text class="toolbar-animal">{{ currentAnimal?.name || '' }}</text>
          <text class="toolbar-arrow">▼</text>
        </view>
      </view>
      <view class="tool-btn font" @tap="showFontPicker = true">
        <text>Aa</text>
      </view>
    </view>

    <!-- 切换动物弹窗 -->
    <view class="modal-overlay" v-if="showAnimalPicker" @tap="showAnimalPicker = false">
      <view class="animal-modal" @tap.stop>
        <text class="modal-title">切换动物</text>
        <view class="animal-list-mini">
          <view
            v-for="animal in unlockedAnimals"
            :key="animal.id"
            class="animal-mini"
            :class="{ active: currentAnimalId === animal.id }"
            :style="{ borderColor: animal.style.primaryColor }"
            @tap="switchAnimal(animal.id)"
          >
            <text class="mini-emoji">{{ getEmoji(animal.species) }}</text>
            <text class="mini-name">{{ animal.name }}</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 编辑区 -->
    <view class="editor-area" :style="editorStyle">
      <textarea
        v-model="content"
        class="editor-textarea"
        :placeholder="placeholder"
        :style="textStyle"
        maxlength="2000"
        auto-height
        @input="onInput"
      />
      <text class="char-count">{{ content.length }} / 2000</text>
    </view>

    <!-- 图片区域 -->
    <view class="images-section" v-if="imagePaths.length > 0">
      <view class="image-list">
        <view v-for="(img, idx) in imagePaths" :key="idx" class="image-item">
          <image :src="img" mode="aspectFill" class="image-preview" @tap="previewImage(idx)" />
          <view class="image-remove" @tap="removeImage(idx)">
            <text class="remove-text">×</text>
          </view>
        </view>
      </view>
    </view>

    <!-- 模板选择（底部横向滑动） -->
    <view class="template-section">
      <scroll-view scroll-x class="template-scroll">
        <view
          v-for="tpl in currentTemplates"
          :key="tpl.id"
          class="template-card"
          :class="{ active: selectedTemplate === tpl.id }"
          :style="{ background: selectedTemplate === tpl.id ? currentAnimal?.style.primaryColor : currentAnimal?.style.secondaryColor }"
          @tap="selectedTemplate = tpl.id"
        >
          <text class="tpl-name" :style="{ color: selectedTemplate === tpl.id ? '#fff' : '#666' }">{{ tpl.name }}</text>
        </view>
      </scroll-view>
    </view>

    <!-- 底部操作栏 -->
    <view class="bottom-bar">
      <view class="bottom-actions">
        <view class="action-icon" @tap="addImage">
          <text>🖼</text>
          <text class="action-label">图片</text>
        </view>
        <view class="action-icon" @tap="undo">
          <text>↩️</text>
          <text class="action-label">撤回</text>
        </view>
        <view class="action-icon" @tap="clearContent">
          <text>🗑️</text>
          <text class="action-label">清空</text>
        </view>
      </view>
      <view class="save-btn" @tap="saveDraft">
        <text>💾 保存</text>
      </view>
      <view class="export-btn" @tap="exportImage">
        <text>📷 导出图片</text>
      </view>
    </view>

    <!-- 隐藏 Canvas（用于导出图片） -->
    <view class="export-canvas-wrap">
      <canvas type="2d" id="exportCanvas" class="export-canvas" />
    </view>

    <!-- 字体弹窗 -->
    <view class="modal-overlay" v-if="showFontPicker" @tap="showFontPicker = false">
      <view class="font-modal" @tap.stop>
        <text class="modal-title">选择书写字体</text>
        <text class="modal-subtitle">全局生效</text>
        <view class="font-list">
          <view
            v-for="font in allFonts"
            :key="font.id"
            class="font-item"
            :class="{ active: fontSettings.fontId === font.id }"
            @tap="setFont(font.id)"
          >
            <text class="font-name">{{ font.name }}</text>
            <text class="font-desc">{{ font.description }}</text>
            <text v-if="currentAnimal && font.recommendedFor.includes(currentAnimal.id)" class="font-recommend">推荐</text>
          </view>
        </view>
        <view class="size-section">
          <text class="size-label">字号</text>
          <view class="size-options">
            <view v-for="size in fontSizes" :key="size.id" class="size-btn"
              :class="{ active: fontSettings.fontSizeId === size.id }"
              @tap="setFontSize(size.id)">
              <text>{{ size.label }}</text>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { animals, getAnimal, getAnimalEmoji } from '../../templates/animals'
import { fonts, fontSizes } from '../../templates/fonts'
import {
  getFontSettings, saveFontSettings, saveNote, getNotes,
  isAnimalUnlocked,
  type NoteRecord, type FontSettings,
} from '../../utils/storage'
import { exportNoteAsImage } from '../../utils/export'
import { getCurrentAnimalId, setCurrentAnimalId } from '../../utils/animalState'

const content = ref('')
const imagePaths = ref<string[]>([])
const selectedTemplate = ref('')
const showFontPicker = ref(false)
const showAnimalPicker = ref(false)
const allFonts = fonts
const editNoteId = ref('')  // 编辑已有笔记时的 ID

// 撤回栈
const undoStack = ref<string[]>([])
const MAX_UNDO = 20

// 动物
const currentAnimalId = ref('anan')
const currentAnimal = computed(() => getAnimal(currentAnimalId.value))
const currentAnimalEmoji = computed(() => {
  const animal = currentAnimal.value
  return animal ? getAnimalEmoji(animal.species) : '🐾'
})
const currentTemplates = computed(() => currentAnimal.value?.templates || [])

const unlockedAnimals = animals.filter(a => isAnimalUnlocked(a.id))

function getEmoji(species: string) { return getAnimalEmoji(species) }

function switchAnimal(id: string) {
  currentAnimalId.value = id
  setCurrentAnimalId(id)
  const animal = getAnimal(id)
  if (animal?.templates.length) {
    selectedTemplate.value = animal.templates[0].id
  }
  showAnimalPicker.value = false
}

const fontSettings = ref<FontSettings>(getFontSettings())

// 自动草稿定时器
let autoDraftTimer: ReturnType<typeof setInterval> | null = null
let lastSavedContent = ''

const editorStyle = computed(() => {
  const animal = currentAnimal.value
  if (!animal) return {}
  return {
    background: animal.style.bgColor,
    borderRadius: animal.layout.borderRadius + 'rpx',
    padding: animal.layout.padding + 'rpx',
  }
})

const textStyle = computed(() => {
  const animal = currentAnimal.value
  const size = fontSizes.find(s => s.id === fontSettings.value.fontSizeId)?.value || 15
  if (!animal) return { fontSize: size + 'px' }
  return {
    fontSize: size + 'px',
    lineHeight: animal.layout.lineHeight,
    color: animal.style.fontColor,
  }
})

const placeholder = computed(() => {
  return `在${currentAnimal.value?.name || ''}的笔记里写点什么吧…`
})

// 加载已有笔记或草稿
// 用 onLoad 接收参数（小程序兼容）
let pageQuery: Record<string, string> = {}
// @ts-ignore
if (typeof onLoad !== 'undefined') {
  // uni-app 会注入 onLoad
} 

onMounted(() => {
  // 尝试多种方式获取参数
  try {
    const pages = getCurrentPages()
    const currentPage = pages[pages.length - 1] as any
    pageQuery = currentPage?.options || currentPage?.$page?.options || {}
  } catch {}

  // 编辑已有笔记
  if (pageQuery.noteId) {
    editNoteId.value = pageQuery.noteId
    const note = getNotes().find(n => n.id === pageQuery.noteId)
    if (note) {
      content.value = note.content
      imagePaths.value = note.imagePaths || []
      selectedTemplate.value = note.templateId || ''
      currentAnimalId.value = note.animalId
      fontSettings.value = {
        fontId: note.fontId || fontSettings.value.fontId,
        fontSizeId: note.fontSizeId || fontSettings.value.fontSizeId,
      }
      lastSavedContent = note.content
    }
  } else {
    // 新建笔记：从 URL 获取 animalId，否则用当前选中
    if (pageQuery.animalId) {
      currentAnimalId.value = pageQuery.animalId
      setCurrentAnimalId(pageQuery.animalId)
    } else {
      currentAnimalId.value = getCurrentAnimalId()
    }
    // 加载推荐字体
    const animal = getAnimal(currentAnimalId.value)
    if (animal) {
      fontSettings.value.fontId = animal.recommendedFont
    }
    // 加载草稿
    loadDraft()
  }

  // 默认选中第一个模板
  if (!selectedTemplate.value && currentTemplates.value.length > 0) {
    selectedTemplate.value = currentTemplates.value[0].id
  }

  // 自动草稿（每 5 秒）
  autoDraftTimer = setInterval(() => {
    autoSaveDraft()
  }, 5000)
})

onUnmounted(() => {
  if (autoDraftTimer) clearInterval(autoDraftTimer)
  // 离开时保存草稿
  autoSaveDraft()
})

function onInput() {
  // 记录撤回栈
  if (undoStack.value.length === 0 || undoStack.value[undoStack.value.length - 1] !== content.value) {
    undoStack.value.push(content.value)
    if (undoStack.value.length > MAX_UNDO) undoStack.value.shift()
  }
}

function loadDraft() {
  try {
    const draft = uni.getStorageSync('qzy_draft')
    if (draft) {
      const parsed = JSON.parse(draft)
      if (parsed.content) {
        content.value = parsed.content
        currentAnimalId.value = parsed.animalId || currentAnimalId.value
        selectedTemplate.value = parsed.templateId || ''
        imagePaths.value = parsed.imagePaths || []
        lastSavedContent = parsed.content
      }
    }
  } catch {}
}

function autoSaveDraft() {
  if (content.value.trim() && content.value !== lastSavedContent) {
    const draft = {
      content: content.value,
      animalId: currentAnimalId.value,
      templateId: selectedTemplate.value,
      imagePaths: imagePaths.value,
      savedAt: Date.now(),
    }
    try {
      uni.setStorageSync('qzy_draft', JSON.stringify(draft))
      lastSavedContent = content.value
    } catch {}
  }
}

function clearDraft() {
  try { uni.removeStorageSync('qzy_draft') } catch {}
}

// === 字体 ===
function setFont(fontId: string) {
  fontSettings.value.fontId = fontId
  saveFontSettings(fontSettings.value)
}

function setFontSize(sizeId: string) {
  fontSettings.value.fontSizeId = sizeId
  saveFontSettings(fontSettings.value)
}

// === 编辑操作 ===
function undo() {
  if (undoStack.value.length > 1) {
    undoStack.value.pop()  // 弹出当前状态
    content.value = undoStack.value[undoStack.value.length - 1]
  } else if (undoStack.value.length === 1) {
    content.value = ''
    undoStack.value = []
  }
}

function clearContent() {
  if (!content.value.trim() && imagePaths.value.length === 0) return
  uni.showModal({
    title: '确认清空',
    content: '确定要清空所有内容吗？',
    success: (res) => {
      if (res.confirm) {
        content.value = ''
        imagePaths.value = []
        undoStack.value = []
      }
    },
  })
}

function goBack() {
  if (content.value.trim()) {
    autoSaveDraft()
  }
  uni.navigateBack({})
}

// === 图片 ===
function addImage() {
  if (imagePaths.value.length >= 9) {
    uni.showToast({ title: '最多 9 张图片', icon: 'none' })
    return
  }
  uni.chooseImage({
    count: 9 - imagePaths.value.length,
    sizeType: ['compressed'],
    sourceType: ['album', 'camera'],
    success: (res) => {
      imagePaths.value.push(...res.tempFilePaths)
    },
  })
}

function removeImage(idx: number) {
  imagePaths.value.splice(idx, 1)
}

function previewImage(idx: number) {
  uni.previewImage({
    current: imagePaths.value[idx],
    urls: imagePaths.value,
  })
}

// === 保存 ===
function saveDraft() {
  if (!content.value.trim()) {
    uni.showToast({ title: '请先写点什么', icon: 'none' })
    return
  }
  const note: NoteRecord = {
    id: editNoteId.value || Date.now().toString(),
    animalId: currentAnimalId.value,
    content: content.value,
    templateId: selectedTemplate.value || currentTemplates.value[0]?.id || '',
    fontId: fontSettings.value.fontId,
    fontSizeId: fontSettings.value.fontSizeId,
    imagePaths: imagePaths.value.length > 0 ? [...imagePaths.value] : undefined,
    starred: false,
    hidden: false,
    createdAt: editNoteId.value ? (getNotes().find(n => n.id === editNoteId.value)?.createdAt || Date.now()) : Date.now(),
    updatedAt: Date.now(),
  }
  saveNote(note)
  clearDraft()
  uni.showToast({ title: '已保存', icon: 'success' })
  setTimeout(() => {
    if (!editNoteId.value) {
      // 新笔记保存后返回
      uni.navigateBack({})
    }
  }, 800)
}

function exportImage() {
  if (!content.value.trim()) {
    uni.showToast({ title: '请先写点什么', icon: 'none' })
    return
  }
  // 先保存笔记
  const note: NoteRecord = {
    id: editNoteId.value || Date.now().toString(),
    animalId: currentAnimalId.value,
    content: content.value,
    templateId: selectedTemplate.value || currentTemplates.value[0]?.id || '',
    fontId: fontSettings.value.fontId,
    fontSizeId: fontSettings.value.fontSizeId,
    imagePaths: imagePaths.value.length > 0 ? [...imagePaths.value] : undefined,
    starred: false,
    hidden: false,
    createdAt: editNoteId.value ? (getNotes().find(n => n.id === editNoteId.value)?.createdAt || Date.now()) : Date.now(),
    updatedAt: Date.now(),
  }

  uni.showLoading({ title: '生成图片中…' })
  exportNoteAsImage(note)
    .then(() => {
      uni.hideLoading()
      uni.showToast({ title: '已保存到相册', icon: 'success' })
    })
    .catch((err) => {
      uni.hideLoading()
      // Canvas 不支持时的降级：提示开发中
      uni.showToast({ title: '图片导出功能开发中', icon: 'none' })
    })
}
</script>

<style scoped>
.page { min-height: 100vh; background: #FFF9F5; display: flex; flex-direction: column; }

/* 顶部工具栏 */
.toolbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 20rpx 30rpx;
}
.tool-btn {
  padding: 12rpx 24rpx; border-radius: 8rpx; background: #f5f5f5;
  font-size: 26rpx; color: #666;
}
.tool-btn.font { background: #FFF5E8; color: #8B7355; }
.toolbar-center { flex: 1; text-align: center; }
.toolbar-animal-row { display: inline-flex; align-items: center; gap: 8rpx; }
.toolbar-emoji { font-size: 28rpx; }
.toolbar-animal { font-size: 28rpx; color: #666; }
.toolbar-arrow { font-size: 18rpx; color: #ccc; }

/* 编辑区 */
.editor-area {
  flex: 1; margin: 0 30rpx; min-height: 500rpx; position: relative;
}
.editor-textarea {
  width: 100%; min-height: 400rpx; font-size: 30rpx; line-height: 2;
}
.char-count {
  position: absolute; bottom: 10rpx; right: 10rpx;
  font-size: 22rpx; color: #ccc;
}

/* 图片区域 */
.images-section { margin: 16rpx 30rpx 0; }
.image-list { display: flex; flex-wrap: wrap; gap: 12rpx; }
.image-item { position: relative; }
.image-preview { width: 160rpx; height: 160rpx; border-radius: 12rpx; }
.image-remove {
  position: absolute; top: -8rpx; right: -8rpx;
  width: 36rpx; height: 36rpx; border-radius: 50%; background: rgba(0,0,0,0.5);
  display: flex; align-items: center; justify-content: center;
}
.remove-text { color: #fff; font-size: 24rpx; }

/* 模板选择 */
.template-section { margin: 20rpx 0; }
.template-scroll { white-space: nowrap; padding: 0 30rpx; }
.template-card {
  display: inline-flex; flex-direction: column;
  padding: 16rpx 28rpx; border-radius: 20rpx;
  margin-right: 12rpx;
}
.tpl-name { font-size: 26rpx; font-weight: 500; }

/* 底部操作栏 */
.bottom-bar {
  display: flex; align-items: center; padding: 16rpx 30rpx 40rpx;
  gap: 16rpx; border-top: 1rpx solid #f0f0f0; background: #fff;
}
.bottom-actions { display: flex; gap: 24rpx; }
.action-icon {
  display: flex; flex-direction: column; align-items: center; gap: 4rpx;
}
.action-label { font-size: 20rpx; color: #999; }
.save-btn {
  flex: 1; padding: 20rpx; border-radius: 12rpx;
  text-align: center; font-size: 28rpx; font-weight: 600;
  background: #f5f5f5; color: #666;
}
.export-btn {
  flex: 1; padding: 20rpx; border-radius: 12rpx;
  text-align: center; font-size: 28rpx; font-weight: 600;
  background: linear-gradient(135deg, #C9A88A, #B8956A); color: #fff;
}

/* 字体弹窗 */
.modal-overlay {
  position: fixed; top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.5); z-index: 200;
  display: flex; align-items: flex-end;
}
.font-modal {
  width: 100%; background: #fff; border-radius: 32rpx 32rpx 0 0;
  padding: 40rpx 30rpx 60rpx; max-height: 70vh;
}
.modal-title { font-size: 34rpx; font-weight: bold; color: #333; display: block; text-align: center; }
.modal-subtitle { font-size: 24rpx; color: #999; display: block; text-align: center; margin: 8rpx 0 30rpx; }
.font-list { max-height: 40vh; overflow-y: auto; }
.font-item {
  padding: 24rpx 20rpx; border-radius: 12rpx; margin-bottom: 12rpx;
  background: #f8f8f8; position: relative;
}
.font-item.active { background: #FFF5E8; border: 2rpx solid #C9A88A; }
.font-name { font-size: 30rpx; font-weight: 600; color: #333; display: block; }
.font-desc { font-size: 24rpx; color: #999; display: block; margin-top: 4rpx; }
.font-recommend {
  position: absolute; top: 12rpx; right: 12rpx;
  font-size: 20rpx; color: #C9A88A; background: #FFF5E8;
  padding: 4rpx 12rpx; border-radius: 8rpx;
}
.size-section { margin-top: 24rpx; display: flex; align-items: center; justify-content: space-between; }
.size-label { font-size: 28rpx; color: #333; font-weight: 600; }
.size-options { display: flex; gap: 16rpx; }
.size-btn { padding: 12rpx 32rpx; border-radius: 8rpx; background: #f5f5f5; font-size: 26rpx; color: #666; }
.size-btn.active { background: #C9A88A; color: #fff; }

/* 切换动物弹窗 */
.animal-modal {
  width: 100%; background: #fff; border-radius: 32rpx 32rpx 0 0;
  padding: 40rpx 30rpx 60rpx;
}
.animal-list-mini {
  display: flex; flex-wrap: wrap; gap: 16rpx; margin-top: 24rpx;
}
.animal-mini {
  display: flex; flex-direction: column; align-items: center;
  padding: 20rpx 28rpx; border-radius: 16rpx;
  border: 2rpx solid #e8e8e8; min-width: 120rpx;
}
.animal-mini.active { border-width: 3rpx; background: #FFF9F5; }
.mini-emoji { font-size: 40rpx; }
.mini-name { font-size: 24rpx; color: #666; margin-top: 8rpx; }

/* 隐藏的导出 Canvas */
.export-canvas-wrap {
  position: fixed; left: -9999px; top: -9999px;
  width: 750px; height: 1000px; overflow: hidden;
}
.export-canvas {
  width: 750px; height: 1000px;
}
</style>
