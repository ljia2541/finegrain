const { DIMENSION_MAP } = require('../../utils/cpti')
const { drawResultPoster, savePoster } = require('../../utils/poster')
const allRelations = require('../../data/relations')

const DIM_COLORS = {
  C: 'linear-gradient(90deg, #f093fb, #f5576c)',
  G: 'linear-gradient(90deg, #4facfe, #00f2fe)',
  L: 'linear-gradient(90deg, #43e97b, #38f9d7)',
  S: 'linear-gradient(90deg, #fa709a, #fee140)',
  T: 'linear-gradient(90deg, #a18cd1, #fbc2eb)',
}

Page({
  data: {
    mainType: '',
    typeName: '',
    cpId: '',
    dims: [],
    allRelations: [],
  },

  onLoad(options) {
    const { C, G, L, S, T, type, cpId } = options
    const normalized = { C: +C, G: +G, L: +L, S: +S, T: +T }

    const dims = ['C', 'G', 'L', 'S', 'T'].map(key => ({
      key,
      name: DIMENSION_MAP[key],
      value: normalized[key],
      color: DIM_COLORS[key],
    }))

    this.pageData = { normalized, mainType: type, cpId }

    this.setData({
      mainType: type,
      typeName: DIMENSION_MAP[type],
      cpId,
      dims,
      allRelations,
    })
  },

  copyCpId() {
    wx.setClipboardData({
      data: this.data.cpId,
      success() {
        wx.showToast({ title: '已复制', icon: 'success' })
      },
    })
  },

  savePoster() {
    wx.showLoading({ title: '生成海报...' })
    const query = wx.createSelectorQuery()
    query.select('#posterCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res || !res[0]) {
          wx.hideLoading()
          wx.showToast({ title: '生成失败', icon: 'none' })
          return
        }
        const canvas = res[0].node
        const { normalized, mainType, cpId } = this.pageData
        const dims = ['C', 'G', 'L', 'S', 'T'].map(k => ({
          key: k, value: normalized[k],
        }))

        drawResultPoster(canvas, {
          width: 375,
          height: 667,
          mainType,
          typeName: this.data.typeName,
          dims,
          cpId,
          relationId: mainType.charCodeAt(0) % 25 + 1,
        })

        setTimeout(() => {
          savePoster(canvas, 375, 667)
            .then(() => wx.hideLoading())
            .catch(() => {
              wx.hideLoading()
              wx.showToast({ title: '保存失败', icon: 'none' })
            })
        }, 300)
      })
  },

  goMatch() {
    wx.navigateTo({ url: '/pages/match/match' })
  },

  goAtlas() {
    wx.navigateTo({ url: '/pages/atlas/atlas' })
  },

  onShareAppMessage() {
    return {
      title: '我测出了关系性格，快来匹配看看你们的关系',
      path: '/pages/index/index',
    }
  },
})
