/**
 * 轻治愈动物笔记 - 字体系统
 * 6款免费商用字体
 */

export interface FontConfig {
  id: string
  name: string
  description: string
  cssFamily: string
  localPath?: string   // 本地字体文件路径（小程序需要打包或下载）
  recommendedFor: string[]  // 推荐适配的动物ID
}

export const fonts: FontConfig[] = [
  {
    id: 'warm_kai',
    name: '温润楷体',
    description: '适合古风书写',
    cssFamily: '"LXGW WenKai", "Ma Shan Zheng", serif',
    recommendedFor: ['momo'],
  },
  {
    id: 'round_cream',
    name: '圆润奶油体',
    description: '适合森系治愈',
    cssFamily: '"ZCOOL KuaiLe", "Happy Monkey", cursive',
    recommendedFor: ['tietie'],
  },
  {
    id: 'serif_jp',
    name: '日系细宋体',
    description: '全局默认·简约雅致',
    cssFamily: '"Noto Serif SC", "Source Han Serif SC", serif',
    recommendedFor: ['anan'],
  },
  {
    id: 'art_handwrite',
    name: '文艺手写体',
    description: '适合旅行复古',
    cssFamily: '"Long Cang", "ZCOOL QingKe HuangYou", cursive',
    recommendedFor: ['youyou'],
  },
  {
    id: 'biz_hei',
    name: '商务标准黑体',
    description: '适合日常办公',
    cssFamily: '"Noto Sans SC", "Source Han Sans SC", sans-serif',
    recommendedFor: ['banban'],
  },
  {
    id: 'thin_hei',
    name: '极简细黑体',
    description: '适合冷淡极简',
    cssFamily: '"Noto Sans SC", "Helvetica Neue", sans-serif',
    recommendedFor: ['diandian', 'chacha'],
  },
]

export function getFont(id: string): FontConfig | undefined {
  return fonts.find((f) => f.id === id)
}

export function getDefaultFont(): FontConfig {
  return fonts.find((f) => f.id === 'serif_jp')!
}

export function getRecommendedFont(animalId: string): FontConfig {
  const match = fonts.find((f) => f.recommendedFor.includes(animalId))
  return match || getDefaultFont()
}

export const fontSizes = [
  { id: 'small', label: '小', value: 13 },
  { id: 'medium', label: '中', value: 15 },
  { id: 'large', label: '大', value: 18 },
] as const

export type FontSizeId = typeof fontSizes[number]['id']
