<script lang="ts">
export default {
  onLaunch() {
    console.log('排版小动物 App Launch')
  },
  onShow() {
    console.log('App Show')
  },
  onHide() {
    console.log('App Hide')
  },
}
</script>

<style>
/* 全局治愈系配色 */
page {
  background: #FFF9F5;
  font-family: -apple-system, BlinkMacSystemFont, 'Helvetica Neue', Helvetica, 'PingFang SC', 'Microsoft YaHei', Arial, sans-serif;
  color: #3D2B1F;
}
</style>
