Page({
  data: {},

  startTest() {
    wx.navigateTo({ url: '/pages/question/question' })
  },

  goMatch() {
    wx.navigateTo({ url: '/pages/match/match' })
  },

  goAtlas() {
    wx.navigateTo({ url: '/pages/atlas/atlas' })
  }
})
