/**
 * Canvas 海报绘制工具
 * 纯前端绘制关系卡片海报，保存到相册
 */

const relations = require('../data/relations')

// 关系对应的渐变色对
const GRADIENT_COLORS = {
  1: ['#667eea', '#764ba2'],
  2: ['#89f7fe', '#66a6ff'],
  3: ['#f093fb', '#f5576c'],
  4: ['#ff6a00', '#ee0979'],
  5: ['#11998e', '#38ef7d'],
  6: ['#fc5c7d', '#6a82fb'],
  7: ['#f6d365', '#fda085'],
  8: ['#4facfe', '#00f2fe'],
  9: ['#43e97b', '#38f9d7'],
  10: ['#fa709a', '#fee140'],
  11: ['#a18cd1', '#fbc2eb'],
  12: ['#fddb92', '#d1fdff'],
  13: ['#c471f5', '#fa71cd'],
  14: ['#48c6ef', '#6f86d6'],
  15: ['#e0c3fc', '#8ec5fc'],
  16: ['#f6d365', '#f5af19'],
  17: ['#667eea', '#764ba2'],
  18: ['#84fab0', '#8fd3f4'],
  19: ['#fccb90', '#d57eeb'],
  20: ['#a1c4fd', '#c2e9fb'],
  21: ['#d4fc79', '#96e6a1'],
  22: ['#fbc2eb', '#a6c1ee'],
  23: ['#ffecd2', '#fcb69f'],
  24: ['#e0c3fc', '#8ec5fc'],
  25: ['#f5af19', '#f12711'],
}

/**
 * 绘制简约双人图标（Canvas 原生绘制）
 * @param {CanvasRenderingContext2D} ctx
 * @param {number} cx - 中心 x
 * @param {number} cy - 中心 y
 * @param {number} size - 整体大小
 * @param {number} relationId - 关系 ID（决定姿态）
 */
function drawTwoPeople(ctx, cx, cy, size, relationId) {
  const r = size * 0.18 // 头部半径
  const bodyH = size * 0.35
  const bodyW = size * 0.12
  const gap = size * 0.15

  // 左人
  const lx = cx - gap
  const ly = cy
  // 右人
  const rx = cx + gap
  const ry = cy

  ctx.fillStyle = 'rgba(255,255,255,0.9)'

  // 根据关系 ID 微调姿态
  if ([1, 2, 3, 7, 15, 17, 22].includes(relationId)) {
    // 靠近型：头靠头/肩并肩
    drawPerson(ctx, cx, cy + size * 0.05, r * 0.85, bodyH * 0.85, gap * 0.3)
  } else if ([4, 10, 12, 16].includes(relationId)) {
    // 活跃型：跳跃/举手
    drawPerson(ctx, lx, ly - size * 0.05, r, bodyH, 0, true)
    drawPerson(ctx, rx, ry - size * 0.05, r, bodyH, 0, true)
  } else if ([5, 6, 8, 19, 20].includes(relationId)) {
    // 一前一后/守护型
    drawPerson(ctx, lx - size * 0.05, ly, r * 0.8, bodyH * 0.8, 0)
    drawPerson(ctx, rx + size * 0.05, ry, r, bodyH, 0)
  } else {
    // 标准型：并排
    drawPerson(ctx, lx, ly, r, bodyH, 0)
    drawPerson(ctx, rx, ry, r, bodyH, 0)
  }
}

function drawPerson(ctx, x, y, headR, bodyH, offsetX, jumping) {
  const jy = jumping ? -headR * 0.5 : 0
  // 头
  ctx.beginPath()
  ctx.arc(x + offsetX, y - bodyH * 0.5 + jy, headR, 0, Math.PI * 2)
  ctx.fill()
  // 身体（圆角矩形简化为椭圆）
  ctx.beginPath()
  ctx.ellipse(x + offsetX, y + bodyH * 0.15 + jy, headR * 0.7, bodyH * 0.5, 0, 0, Math.PI * 2)
  ctx.fill()
}

/**
 * 绘制结果页海报
 */
function drawResultPoster(canvas, options) {
  const { width, height, mainType, typeName, dims, cpId, relationId } = options
  const ctx = canvas.getContext('2d')
  const dpr = wx.getWindowInfo().pixelRatio || 2

  canvas.width = width * dpr
  canvas.height = height * dpr
  ctx.scale(dpr, dpr)

  // 1. 渐变背景
  const colors = GRADIENT_COLORS[relationId] || ['#667eea', '#764ba2']
  const grad = ctx.createLinearGradient(0, 0, width, height)
  grad.addColorStop(0, colors[0])
  grad.addColorStop(1, colors[1])
  ctx.fillStyle = grad
  ctx.fillRect(0, 0, width, height)

  // 2. 装饰圆
  ctx.globalAlpha = 0.08
  ctx.fillStyle = '#fff'
  ctx.beginPath()
  ctx.arc(width * 0.8, height * 0.15, 120, 0, Math.PI * 2)
  ctx.fill()
  ctx.beginPath()
  ctx.arc(width * 0.2, height * 0.85, 80, 0, Math.PI * 2)
  ctx.fill()
  ctx.globalAlpha = 1

  // 3. 顶部标题
  ctx.fillStyle = 'rgba(255,255,255,0.7)'
  ctx.font = '14px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText('关系匹配图鉴 · CPTI', width / 2, 40)

  // 4. 主类型大字
  ctx.fillStyle = '#fff'
  ctx.font = 'bold 64px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText(mainType, width / 2, 120)

  ctx.font = '20px sans-serif'
  ctx.fillStyle = 'rgba(255,255,255,0.9)'
  ctx.fillText(typeName, width / 2, 150)

  // 5. 绘制双人图标
  drawTwoPeople(ctx, width / 2, 250, 160, relationId)

  // 6. 维度条
  const dimY = 360
  const dimKeys = ['C', 'G', 'L', 'S', 'T']
  const dimNames = ['掌控', '感温', '理智', '社交', '自由']
  dims.forEach((dim, i) => {
    const dy = dimY + i * 36
    ctx.fillStyle = 'rgba(255,255,255,0.6)'
    ctx.font = '12px sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(dimKeys[i] + ' ' + dimNames[i], 40, dy)

    // 进度条背景
    ctx.fillStyle = 'rgba(255,255,255,0.2)'
    roundRectPath(ctx, 120, dy - 10, 160, 14, 7)
    ctx.fill()

    // 进度条填充
    ctx.fillStyle = 'rgba(255,255,255,0.8)'
    const barW = Math.max(1, (dim.value / 100) * 160)
    roundRectPath(ctx, 120, dy - 10, barW, 14, 7)
    ctx.fill()

    // 数值
    ctx.fillStyle = '#fff'
    ctx.font = '12px sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(dim.value, 290, dy)
  })

  // 7. CPID
  ctx.fillStyle = 'rgba(255,255,255,0.5)'
  ctx.font = '12px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText('匹配码', width / 2, 570)

  ctx.fillStyle = '#fff'
  ctx.font = 'bold 28px sans-serif'
  ctx.fillText(cpId, width / 2, 605)

  // 8. 底部提示
  ctx.fillStyle = 'rgba(255,255,255,0.4)'
  ctx.font = '11px sans-serif'
  ctx.fillText('长按保存图片 · 发给 TA 测匹配', width / 2, height - 20)
}

/**
 * 绘制匹配结果海报
 */
function drawMatchPoster(canvas, options) {
  const { width, height, relation, similarity, myType, taType } = options
  const ctx = canvas.getContext('2d')
  const dpr = wx.getWindowInfo().pixelRatio || 2

  canvas.width = width * dpr
  canvas.height = height * dpr
  ctx.scale(dpr, dpr)

  // 1. 渐变背景
  const colors = GRADIENT_COLORS[relation.id] || ['#667eea', '#764ba2']
  const grad = ctx.createLinearGradient(0, 0, width, height)
  grad.addColorStop(0, colors[0])
  grad.addColorStop(1, colors[1])
  ctx.fillStyle = grad
  ctx.fillRect(0, 0, width, height)

  // 2. 装饰
  ctx.globalAlpha = 0.06
  ctx.fillStyle = '#fff'
  ctx.beginPath()
  ctx.arc(width * 0.5, height * 0.3, 200, 0, Math.PI * 2)
  ctx.fill()
  ctx.globalAlpha = 1

  // 3. 匹配度
  ctx.fillStyle = 'rgba(255,255,255,0.7)'
  ctx.font = '14px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText('关系匹配图鉴 · CPTI', width / 2, 40)

  ctx.fillStyle = '#fff'
  ctx.font = 'bold 72px sans-serif'
  ctx.fillText(similarity + '%', width / 2, 120)

  // 4. 关系名称
  ctx.font = 'bold 32px sans-serif'
  ctx.fillText(relation.name, width / 2, 170)

  // 5. 双人图
  drawTwoPeople(ctx, width / 2, 280, 180, relation.id)

  // 6. 关系描述
  ctx.fillStyle = 'rgba(255,255,255,0.85)'
  ctx.font = '15px sans-serif'
  wrapText(ctx, relation.desc, width / 2, 400, width - 80, 24)

  // 7. VS 对比
  const vsY = 500
  ctx.font = 'bold 16px sans-serif'
  ctx.fillStyle = '#fff'
  ctx.textAlign = 'center'

  // 左
  ctx.fillText('你', width * 0.25, vsY)
  ctx.font = 'bold 24px sans-serif'
  ctx.fillText(myType, width * 0.25, vsY + 30)

  // VS
  ctx.font = '14px sans-serif'
  ctx.fillStyle = 'rgba(255,255,255,0.5)'
  ctx.fillText('VS ❤️', width * 0.5, vsY + 15)

  // 右
  ctx.font = 'bold 16px sans-serif'
  ctx.fillStyle = '#fff'
  ctx.fillText('TA', width * 0.75, vsY)
  ctx.font = 'bold 24px sans-serif'
  ctx.fillText(taType, width * 0.75, vsY + 30)

  // 8. 底部
  ctx.fillStyle = 'rgba(255,255,255,0.4)'
  ctx.font = '11px sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText('长按保存 · 分享给好友', width / 2, height - 20)
}

// === 工具函数 ===

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arcTo(x + w, y, x + w, y + r, r)
  ctx.lineTo(x + w, y + h - r)
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r)
  ctx.lineTo(x + r, y + h)
  ctx.arcTo(x, y + h, x, y + h - r, r)
  ctx.lineTo(x, y + r)
  ctx.arcTo(x, y, x + r, y, r)
  ctx.closePath()
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  let line = ''
  let currentY = y
  for (let i = 0; i < text.length; i++) {
    const testLine = line + text[i]
    const metrics = ctx.measureText(testLine)
    if (metrics.width > maxWidth && line.length > 0) {
      ctx.fillText(line, x, currentY)
      line = text[i]
      currentY += lineHeight
    } else {
      line = testLine
    }
  }
  if (line) ctx.fillText(line, x, currentY)
}

/**
 * 导出海报并保存到相册
 */
function savePoster(canvas, width, height) {
  return new Promise((resolve, reject) => {
    wx.canvasToTempFilePath({
      canvas,
      width,
      height,
      destWidth: width * 3,
      destHeight: height * 3,
      fileType: 'png',
      quality: 1,
      success: (res) => {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: () => {
            wx.showToast({ title: '已保存到相册', icon: 'success' })
            resolve(res.tempFilePath)
          },
          fail: (err) => {
            if (err.errMsg?.includes('auth deny')) {
              wx.showModal({
                title: '需要相册权限',
                content: '请在设置中允许访问相册',
                confirmText: '去设置',
                success: (r) => { if (r.confirm) wx.openSetting({}) },
              })
            }
            reject(err)
          },
        })
      },
      fail: reject,
    })
  })
}

module.exports = {
  drawResultPoster,
  drawMatchPoster,
  savePoster,
  GRADIENT_COLORS,
}
